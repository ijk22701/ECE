--Execute CREATE DATABASE ECEDB first, then the rest should be good to excecute

CREATE DATABASE ECEDB;



--Table Portion of Query
--DROP TABLE userList
CREATE TABLE userList (
	username varchar(255) NOT NULL PRIMARY KEY,
	password varchar(255),
	adminRoll varchar(255)
	)

	INSERT INTO userList (username, password, adminRoll)
	VALUES ('root', 'r00t', 'a');

	select * from userList	   	 
	
	INSERT INTO userList (username, password, adminRoll)
	VALUES ('root2', 'r00t2', 'abvd');

--DROP TABLE allparts;
CREATE table allparts (
	ID int NOT NULL PRIMARY KEY,
	name varchar(255),
	description varchar(255),
	quantity int,
	instock int,
	)


--DROP TABLE vehicles;
CREATE TABLE vehicles (
	ID int NOT NULL PRIMARY KEY,
	quantityInKit int,
	)

	INSERT INTO vehicles
	VALUES (3, 5);D

	INSERT INTO vehicles
	VALUES (8, 2);	
	
--DROP TABLE gaming_items;
CREATE TABLE gaming_items (
	ID int NOT NULL PRIMARY KEY,
	quantityInKit int,
	)

	INSERT INTO gaming_items 
	VALUES (4, 5);

	INSERT INTO gaming_items 
	VALUES (5, 3);

	INSERT INTO gaming_items 
	VALUES (9, 1);

	INSERT INTO gaming_items
	VALUES (10, 6);

	INSERT INTO gaming_items
	VALUES (11, 3);

	INSERT INTO gaming_items
	VALUES (21, 3);


	select *
	from allparts;

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('1', 'wire', 'a copper wire', '5', '3');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('2', 'book', 'a paper book', '78', '53');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('3', 'helicopter', 'a random helicopter', '3', '1');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('4', 'computer', 'a gaming computer', '10', '5');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('5', 'monitor', 'a gaming monitor 144hz 27inch', '10', '6');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('6', 'raspberry pi', 'a raspberry pi microcomputer gen 4', '22', '16');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('7', 'ring doorbell', 'shows you your front door', '4', '2');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('8', 'Lockeed f-22 Raptor', 'radar cant see this', '126', '32');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('9', 'VR headset', 'the future is here', '2', '1');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('10', 'microphone', 'it picks up the noise', '8', '3');

	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES ('11', 'webcam', 'it watches', '10', '7');

	--------

	--DROP TABLE allkits
	
	CREATE TABLE allkits (
	name varchar(255) NOT NULL PRIMARY KEY,
	description varchar(255),
	)

	INSERT INTO allkits (name, description)
	VALUES ('vehicles', 'A kit containing all vehicles in the database');

	INSERT INTO allkits (name, description)
	VALUES ('gaming_items', 'Items that are used for gaming');


--End of Table Portion



--Start of Kit_PrintAll
GO
CREATE PROCEDURE dbo.Kit_PrintAll

as
BEGIN
	select *
	from dbo.allkits
END
GO
--DROP PROCEDURE dbo.Kit_PrintAll
--End of Kit_PrintAll



--Start of Item_GetByKitName
GO
CREATE PROCEDURE dbo.Item_GetByKitName
	@KitName varchar(255)
as
BEGIN
	EXEC ('SELECT * FROM ' + @KitName + ' INNER JOIN allparts ON allparts.id=' + @KitName + '.id')

END
GO
--DROP PROCEDURE dbo.Item_GetByKitName
--End of Item_GetByKitName



--Start of GetAll
GO
CREATE PROCEDURE dbo.Item_PrintAll

as
BEGIN
	select *
	from dbo.allparts
	ORDER BY ID
END
GO
--DROP PROCEDURE dbo.Item_PrintAll
--End of GetAll



--Start of GetItemByID
GO
CREATE PROCEDURE dbo.Item_GetByID
	@ID varchar(255)
as
BEGIN
	select *
	from dbo.allparts
	where ID = @ID;
END
GO
--DROP PROCEDURE dbo.Item_GetByID
--End of GetItemByID

GO
CREATE PROCEDURE dbo.Item_Add
	@ID varchar(255),
	@name varchar(255),
	@description varchar(255),
	@quantity int,
	@instock int
as
BEGIN
	INSERT INTO allparts (ID, name, description, quantity, instock)
	VALUES (@ID, @name, @description, @quantity, @instock)
END
GO

GO
CREATE PROCEDURE dbo.Item_Delete
	@ID varchar(255)
as
BEGIN
	DELETE FROM allparts
	WHERE ID = @ID
END
GO
--DROP PROCEDURE dbo.Item_Delete

GO
CREATE PROCEDURE dbo.Create_Kit
	@kitname varchar(255), @description varchar(255)
as
BEGIN
	exec ('create table ' + @kitname + '(ID int NOT NULL PRIMARY KEY, quantityInKit int,)')
	INSERT INTO allkits (name, description)
	VALUES (@kitname, @description)
END
GO

--EXEC dbo.Create_Kit @kitname = 'testKit', @description = 'test description'
--select * from allkits
--DROP PROCEDURE dbo.Create_Kit

GO
CREATE PROCEDURE dbo.AddToKit
	@kitname varchar(255), @ID varchar(255), @Quantity varchar(255)
as
BEGIN
	exec ('INSERT INTO ' + @kitname + ' VALUES (' + @ID + ', ' + @Quantity + ')')
END
GO

--exec dbo.AddToKit @kitname = ay, @ID = 5, @Quantity = 12 --test case
--drop procedure dbo.AddToKit;

GO
CREATE PROCEDURE dbo.RemoveFromKit
	@kitname varchar(255), @ID varchar(255)
as
BEGIN
	exec ('DELETE FROM ' + @kitname + ' WHERE ID = ' + @ID)
END
GO

--drop procedure dbo.RemoveFromKit

GO
CREATE PROCEDURE dbo.RemoveKit
	@kitname varchar(255)
as
BEGIN
	exec ('DROP TABLE ' + @kitname)
	DELETE FROM allkits WHERE name = @kitname
END
GO

--drop procedure dbo.RemoveKit


GO
CREATE PROCEDURE dbo.GetKitItemInfo --does not include join like previous version, for getting quantity
	@kitname varchar(255)
as
BEGIN
	exec ('SELECT * FROM ' + @kitname)
END
GO


GO
CREATE PROCEDURE dbo.GetQuantitesFromKit
	@kitname varchar(255)
as
BEGIN
	exec ('SELECT quantityInKit FROM ' + @kitname)
END
GO

--drop procedure dbo.GetQuantitesFromKit


GO
CREATE PROCEDURE dbo.GetUserList
as
BEGIN
	select * from userList
END
GO

GO
CREATE PROCEDURE dbo.GetUserByName
	@username varchar(255)
as
BEGIN
	select * from userList
	where username = @username
END
GO


CREATE PROCEDURE dbo.AddUser
	@username varchar(255), @password varchar(255), @adminRoll varchar(1)
as
BEGIN
	INSERT INTO userList
	VALUES (@username, @password, @adminRoll)
END
GO


CREATE PROCEDURE dbo.DeleteUser
	@username varchar(255)
as
BEGIN
	DELETE FROM userList 
	WHERE username = @username
END
GO


