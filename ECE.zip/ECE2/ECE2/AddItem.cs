﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ECE2
{
    public partial class AddItem : Form
    {
        List<int> ids = new List<int>(); //a list of all ids in use
        List<Item> items = new List<Item>();
        List<string> errorList = new List<string>();
        List<Item> newItems = new List<Item>();
        User activeUser = new User();
        private static string DB_LOG = "DB_LOG.txt";

        public AddItem(User ActiveUser)
        {
            activeUser = ActiveUser;
            InitializeComponent();
            UpdateBinding();
            if (activeUser.AdminRoll == "u")
            {
                button1.Hide();
                label5.Hide();
                IDForDelete.Hide();
            }

        }

        private void UpdateBindingForAdding()
        {
            ItemBox.DataSource = ids;
            ItemBox.DataSource = newItems;
            ItemBox.DisplayMember = "BasicInfo";
        }

        private void UpdateBinding()
        {
            ids.Clear();
            DataAccess db = new DataAccess();
            items = db.PrintAllItems(); //update the list on this page
            ItemBox.DataSource = items;
            ItemBox.DisplayMember = "BasicInfo";
            foreach (Item item in items)
            {
                ids.Add(int.Parse(item.ID)); //fill list with ids in use
            }
        }

        private void ItemAddAdd_Click(object sender, EventArgs e)
        {
            errorList.Clear();

            string itemName = ItemAddName.Text; //the name of the new item being added
            string itemDescription = ItemAddDescription.Text; //description of the new item
            string itemQuantity = ItemAddQuantity.Text; //quantity of the new item
            string itemInStock = ItemAddInstock.Text; //amount of the new item currently in stock

            bool noErrors = true;



            //name errors
            if (itemName == null || itemName.Length == 0)
            {
                errorList.Add("Item name cannot be null");
                noErrors = false;
            }

            if (itemName.Length > 255)
            {
                errorList.Add("Item name must be less than 255 characters");
                noErrors = false;
            }

            //description errors
            if (itemDescription.Length > 255)
            {
                errorList.Add("Item description must be less than 255 characters");
                noErrors = false;
            }

            //quantity errors
            if (itemQuantity == null || itemQuantity.Length == 0)
            {
                errorList.Add("Item quantity cannot be null");
                noErrors = false;
            }

            if (int.TryParse(itemQuantity, out int quantityInt))
            {

                if (quantityInt < 0)
                {
                    errorList.Add("Item quantity must be greater than 0");
                }

            }
            else
            {
                errorList.Add("Quantity must be an integer");
                noErrors = false;
            }

            //instock errors
            if (int.TryParse(itemInStock, out int inStockInt)) {

                if (inStockInt < 0)
                {
                    errorList.Add("Items in stock must be greater than 0");
                }
            
            } else
            {
                errorList.Add("In-stock must be an integer");
                noErrors = false;
            }

            if (itemInStock == null || itemInStock.Length == 0 )
            {
                errorList.Add("In-stock cannot be null");
                noErrors = false;
            }



            if (noErrors)
            {
                //create a new item and fill all the variables with the user entered input
                Item newItem = new Item();
                newItem.ID = GenerateID().ToString();
                newItem.Name = itemName;
                newItem.Description = itemDescription;
                newItem.Quantity = int.Parse(itemQuantity);
                newItem.InStock = int.Parse(itemInStock);

                WriteToLogFile($"+++Item ID {IDForDelete.Text} was added by {activeUser.UserName} on {DateTime.Now}"); //write to log file

                newItems.Add(newItem); //added to newItems, not yet committed to the database at this point
                UpdateBindingForAdding();
                button1.Visible = false;

                //clear all the text boxes
                ItemAddName.Text = "";
                ItemAddDescription.Text = "";
                ItemAddQuantity.Text = "";
                ItemAddInstock.Text = "";
           }
            else
            {
                ItemBox.DataSource = errorList;
            }
          
        }

        /// <summary>
        /// Generates a new ID sequentially, filling spots from items deleted before it. Every ID generated is unique and does not exist on the database. 
        /// </summary>
        /// <returns></returns>
        private int GenerateID() //the solution in this method is by no means perfect but it works for a database that doesn't have tens of thousands of entries
        {

            //BE VERY CAREFUL MODIFYING THIS METHOD, IF IT BREAKS THE ID SYSTEM MIGHT NOT WORK AND THE PROGRAM WILL HAVE A TON OF ISSUES
            //IT WORKS AS IS, DO NOT MODIFY UNLESS YOU ABSOLUTELY NEED TO
            //(and if it breaks after you modify it I probably can't help)
            //-Isaac

            int newid; //the new id being generated
            for (int i = 1; i < ids.Count + 1; i++) //loops through the list of ids in the program
            {
                //if the id does not have a match at this point in the loop, assign that point as the new id (I am unsure how to better explain it, sorry)
                //this fills in gaps when an item is deleted
                if (ids[i - 1] != i) 
                {
                    newid = i;
                    ids.Add(i);
                    ids.Sort();
                    return newid;
                }
            }
            //If the loop gets here, then there are no gaps in the IDs and a new one can be added
            newid = ids.Count + 1;
            ids.Add(newid);
            ids.Sort();
            return newid;
        }


        private void ItemAddBack_Click(object sender, EventArgs e) //sends user back to home page
        {
            this.Hide ();
            Form1 form1 = new Form1(activeUser);
            form1.ShowDialog();
        }

        //I'm sorry this one is so sloppy, I did it really late at night
        private void button1_Click(object sender, EventArgs e) //delete button, missed name change when creating it
        {
            bool errorExists = false;
            DataAccess db = new DataAccess();
            if (IDForDelete.Text == null || IDForDelete.Text == "") //make sure the id for deletion exists
            {
                errorList.Add("ID for delete cannot be null");
                errorExists = true;
            }

            if (int.TryParse(IDForDelete.Text, out int textBox)) //make sure user input is an int
            {
                bool intExists = false;
                foreach (int i in ids)
                {
                    if (textBox == i)
                    {
                        intExists = true;
                    }

                }
                if (intExists == false)
                {
                    errorList.Add("ID must correspond to an existing item");
                    errorExists = true;
                }
            } else
            {
                errorList.Add("ID must be an integer");
                errorExists = true;
            }

            if (!errorExists) //if no errors, run
            {
                DialogResult dialogResult = MessageBox.Show($"Are you sure you want to delete item ID {IDForDelete.Text}?", "Delete User", MessageBoxButtons.YesNo); //dialog box prompting whether or not the user wants to delete the item
                if (dialogResult == DialogResult.Yes)
                {
                    db.DeleteItem(int.Parse(IDForDelete.Text)); //delete the item
                    UpdateBinding();
                    WriteToLogFile($"---Item ID {IDForDelete.Text} was deleted by {activeUser.UserName} on {DateTime.Now}");
                    IDForDelete.Text = "";
                }

            } else
            {
                ItemBox.DataSource = errorList;
            }

        }

        private void Commit_List_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            db.AddItem(newItems); //add new items
            newItems.Clear(); //clear the old list of new items so user can keep adding
            button1.Visible = true;
            UpdateBinding(); //refresh list
        }

        private void ClearError_Click(object sender, EventArgs e)
        {
            UpdateBinding();
        }

        /// <summary>
        /// Writes the string sent to it into the log file
        /// </summary>
        /// <param name="message">The message sent to the log file</param>
        private void WriteToLogFile(string message)
        {
            List<string> logEntries = new List<string>(); //Every string in this list is a line on the log file

            //Add each line in the log file as a string into the logEntries list since they will be deleted when the file is written to
            foreach (string line in System.IO.File.ReadLines(DB_LOG))
            {
                logEntries.Add(line);
            }

            logEntries.Add(message); //Add the user's message to the end of the list


            if (logEntries.Count > 300) //Remove the oldest message if the log goes over 300 items
            {
                logEntries.RemoveAt(0); //oldest message 
            }

            StreamWriter outFile = new StreamWriter(DB_LOG);

            //rewrite each string into the log file from order of oldest to newest
            foreach (string line in logEntries)
            {
                outFile.WriteLine(line);
            }

            outFile.Close();
        }
    }
}
