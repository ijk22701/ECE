﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ECE2
{
    public partial class LoginPage : Form
    {
        List<User> users = new List<User>();
        User currentUser = new User();
        private static string DB_LOG = "DB_LOG.txt";

        public LoginPage()
        {
            DataAccess db = new DataAccess();
            InitializeComponent();
            users = db.GetUserList();
        }

        private void logBtn_Click(object sender, EventArgs e)
        {
            bool validLogin = false;
            foreach (User user in users) //go through user list to look for matches
            {

                if (user.UserName.ToLower() == userTxtBox.Text.ToLower() && user.Password == passTxtBox.Text) //if the username and password both match an existing user, let them into the website
                {
                    validLogin = true;
                    currentUser = user;
                    break;
                }               
            }

            if (validLogin)
            {
                Form1 form = new Form1(currentUser); //show the main menu
                this.Hide();
                form.ShowDialog();
                WriteToLogFile($"...User {currentUser.UserName} signed in at {DateTime.Now}"); //log the time and username login
            }
            else
            {
                MessageBox.Show("The user name or password you entered was incorrect, please try again.");
                WriteToLogFile($"XX_ incorrect password attempt on {DateTime.Now}"); //log incorrect logins
            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// Writes the string sent to it into the log file
        /// </summary>
        /// <param name="message">The message sent to the log file</param>
        private void WriteToLogFile(string message)
        {
            List<string> logEntries = new List<string>(); //Every string in this list is a line on the log file

            //Add each line in the log file as a string into the logEntries list since they will be deleted when the file is written to
            foreach (string line in System.IO.File.ReadLines(DB_LOG))
            {
                logEntries.Add(line);
            }

            logEntries.Add(message); //Add the user's message to the end of the list


            if (logEntries.Count > 300) //Remove the oldest message if the log goes over 300 items
            {
                logEntries.RemoveAt(0); //oldest message 
            }

            StreamWriter outFile = new StreamWriter(DB_LOG);

            //rewrite each string into the log file from order of oldest to newest
            foreach (string line in logEntries)
            {
                outFile.WriteLine(line);
            }

            outFile.Close();
        }
    }
}
