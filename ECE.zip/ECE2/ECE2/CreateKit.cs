﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ECE2 
{
    public partial class CreateKit : Form
    {
        List<Item> items = new List<Item>(); //the list of all items in the database
        List<Kit> kits = new List<Kit>(); //the lsit of all kits in the database
        List<string> errorList= new List<string>(); //the list of current errors
        List<Item> currentKitItems = new List<Item>(); //the list of object kitItem in the current kit
        Kit currentKit = new Kit(); //the current selected kit
        User activeUser = new User(); //the user signed into the database
        private static string DB_LOG = "DB_LOG.txt"; //a variable representing the name of the log file

        /// <summary>
        /// A constructor for the form CreateKit
        /// </summary>
        /// <param name="ActiveUser">The user currently signed in</param>
        public CreateKit(User ActiveUser)
        {
            InitializeComponent();
            activeUser = ActiveUser;
            UpdateBinding();
            if (activeUser.AdminRoll == "u")
            {
                RemoveItem.Hide();
                DeleteKit.Hide();
            }
        }

        /// <summary>
        /// Refreshes the program to its startup state
        /// </summary>
        private void UpdateBinding()
        {
            DataAccess db = new DataAccess();
            kits = db.GetAllKits();
            items = db.PrintAllItems();
            ItemBox.DataSource = items;
            ItemBox.DisplayMember = "BasicInfo";
            KitBox.DataSource = kits;
            KitBox.DisplayMember = "printOut";
            ItemsInKit.DataSource = currentKitItems;
            ItemsInKit.DisplayMember = "BasicInfo";
        }


        private void ItemAddBack_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(activeUser);
            this.Hide();
            form.ShowDialog();

        }

        private void CreateKitButton_Click(object sender, EventArgs e)
        {
            errorList.Clear();
            bool exists = false;
            foreach (Kit kit in kits) //for every kit in the database
            {
                if (KitNameBox.Text == kit.name) //if the user entered name matches the current kit in the loop
                {
                    errorList.Add("A kit with this name already exists"); //kit name is the primary key so it must be unique
                    exists = true;
                    ItemBox.DataSource = errorList;
                }
            }
            if (KitNameBox.Text.Contains(" ") || !KitNameBox.Text.All(char.IsLetter) || KitNameBox.Text == "") //make sure the user entered name is only alphanumeric keys (a-z) and not empty
            {
                errorList.Clear();
                errorList.Add("Kit name cannot contain spaces, numbers, or special characters (A-Z only)");
                ItemBox.DataSource = errorList;
            } else if (!exists) //if all error checks are passed
            {
                DataAccess db = new DataAccess();
                db.AddKit(KitNameBox.Text, KitDescriptionBox.Text);
                UpdateBinding();
                currentKit.name = KitNameBox.Text;
                currentKitItems = db.GetItemByKit(currentKit.name);
                WriteToLogFile($"+++Kit {KitNameBox.Text} was created by {activeUser.UserName} on {DateTime.Now}");
            }
        }

        private void SelectKit_Click(object sender, EventArgs e)
        {
            errorList.Clear();
            bool exists = false; //whether or not the kit name exists
            foreach(Kit kit in kits) //for all kits in the database
            {
                if (KitNameBox.Text == kit.name) //check if the kit exists in the database
                {
                    exists = true;
                }
            }
            if (!exists)
            {
                errorList.Add("Kit name does not exist");
                ItemBox.DataSource = errorList;
            } else //if kit name exists
            {
                DataAccess db = new DataAccess();
                currentKit.name = KitNameBox.Text;
                currentKitItems = db.GetItemByKit(currentKit.name);
                UpdateBinding();
            }
        }

        private void AddItem_Click(object sender, EventArgs e)
        {
            errorList.Clear();
            bool match = false; //if there is an ID match
            bool exists = false; //if the item already exists
            bool success = false; //true when all errors are cleared
            DataAccess db = new DataAccess();
            if (ItemIdBox.Text == null || ItemIdBox.Text == "0") //check for null or zero input
            {
                errorList.Add("ID cannot be null or 0");
            }
            if (!int.TryParse(ItemQuantityBox.Text, out int itemQuantity)) //check if input is an integer
            {
                errorList.Add("Quantity must be an integer");
            } else if (itemQuantity <= 0) //check if integer less than or equal to 0
            {
                errorList.Add("Quantity must be larger than 0");
            }
            else if (int.TryParse(ItemIdBox.Text, out int id)) //make sure item id input is an integer
            {

                foreach(Item item in currentKitItems) //check if the id matches an item already in the kit
                {
                    if (id == int.Parse(item.ID))
                    {
                        match = true;
                        break;
                    }
                }
                foreach(Item item2 in items) //check to make sure the id matches an item in the database
                {
                    if (id == int.Parse(item2.ID))
                    {
                        exists = true;
                    }
                }
                if (match)
                {
                    errorList.Add("ID cannot match with an item already in the kit");

                } else if (!exists)
                {
                    errorList.Add("Item does not exist");

                } else 
                {
                    db.AddToKit(currentKit.name, ItemIdBox.Text, ItemQuantityBox.Text); //add item to kit with values provided by user
                    currentKitItems = db.GetItemByKit(currentKit.name);
                    UpdateBinding();
                    success = true; 
                    WriteToLogFile($"+++Item ID {ItemIdBox.Text} was added to kit {currentKit.name} by {activeUser.UserName} on {DateTime.Now}");
                }

            } else
            {
                errorList.Add("ID must be an integer");
            }

            if (!success) //prints error messages when it was not a success
            {
                UpdateBinding();
                ItemBox.DataSource = errorList;
            }

        }

        private void UpdateQuantity_Click(object sender, EventArgs e)
        {
            bool match = false; //whether or not it matches an item on the current kit
            bool success = false; //whether or not the update was successful

            if (ItemIdBox.Text == null || ItemIdBox.Text == "0")
            {
                errorList.Add("ID cannot be null or 0");
            }
            if (int.TryParse(ItemIdBox.Text, out int id)) //check if user input was an int
            {
                foreach (Item item in currentKitItems)
                {
                    if (id == int.Parse(item.ID)) //if a match is found
                    {
                        DataAccess db = new DataAccess();
                        db.DeleteFromKit(currentKit.name, id.ToString()); //delete from kit for the purpose of updating
                        db.AddToKit(currentKit.name, ItemIdBox.Text, ItemQuantityBox.Text); //add to kit with the new values
                        currentKitItems = db.GetItemByKit(currentKit.name); //update currentKitItems to reflect the new changes
                        UpdateBinding();
                        success = true;
                        match = true;
                        WriteToLogFile($"===Quantity of item ID {ItemIdBox.Text} in {currentKit.name} was changed by {activeUser.UserName} on {DateTime.Now}");
                        break;
                    }
                }
                if (!match)
                {
                    errorList.Add("ID must match an existing item");
                }
            }
            else
            {
                errorList.Add("ID must be an integer");
            }

            if (!success)
            {
                ItemBox.DataSource = errorList;
            }
        }

        private void ClearError_Click(object sender, EventArgs e)
        {
            UpdateBinding();
        }

        private void RemoveItem_Click(object sender, EventArgs e)
        {
            bool match = false;

            if (ItemIdBox.Text == null || ItemIdBox.Text == "0")
            {
                errorList.Add("ID cannot be null or 0");
            }
            if (int.TryParse(ItemIdBox.Text, out int id))
            {

                foreach (Item item in currentKitItems)
                {
                    if (id == int.Parse(item.ID)) //if the user entered ID matches the item ID of the current item in the loop
                    {
                        DialogResult dialogResult = MessageBox.Show($"Are you sure you want to remove item ID {item.ID} from kit {currentKit}?", "", MessageBoxButtons.YesNo); //Dialog box prompting the user on deletion
                        if (dialogResult == DialogResult.Yes)
                        {
                            DataAccess db = new DataAccess();
                            db.DeleteFromKit(currentKit.name, ItemIdBox.Text); //calling the delete function in DataAccess
                            currentKitItems = db.GetItemByKit(currentKit.name); 
                            UpdateBinding();
                            WriteToLogFile($"---item ID {ItemIdBox.Text} was removed in kit {currentKit.name} by {activeUser.UserName} on {DateTime.Now}");
                        }
                        match = true;
                        break;
                    }
                }
                if (!match)
                {
                    errorList.Add("ID must match an existing item");

                }
            }
            else
            {
                errorList.Add("ID must be an integer");
            }

            if (!match)
            {
                ItemBox.DataSource = errorList;
            }

        }

        private void DeleteKit_Click(object sender, EventArgs e)
        {
            errorList.Clear();
            DataAccess db = new DataAccess();
            bool exists = false; //whether or not the user entered kit exists
            foreach (Kit kit in kits)
            {
                if (kit.name == KitNameBox.Text) //searching the list of all kits for one that matches the user input
                {
                    exists = true;
                }
            }
            if (exists) //if the user entered kit exists
            {
                DialogResult dialogResult = MessageBox.Show($"Are you sure you want to delete the kit \"{KitNameBox.Text}\"?", "Delete User", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    List<string> emptyStringList = new List<string>(); //for the purpose of displaying an empty box after deletion of a kit
                    db.DeleteKit(KitNameBox.Text);
                    UpdateBinding();
                    ItemsInKit.DataSource = emptyStringList; //displaying the empty list
                    WriteToLogFile($"---Kit {KitNameBox.Text} was deleted by {activeUser.UserName} on {DateTime.Now}");
                }
            } else
            {               
                errorList.Add("Kit name does not exist");
                ItemBox.DataSource = errorList;               
            }
        }

        /// <summary>
        /// Writes the string sent to it into the log file
        /// </summary>
        /// <param name="message">The message sent to the log file</param>
        private void WriteToLogFile(string message)
        {
            List<string> logEntries = new List<string>(); //Every string in this list is a line on the log file

            //Add each line in the log file as a string into the logEntries list since they will be deleted when the file is written to
            foreach (string line in System.IO.File.ReadLines(DB_LOG))
            {
                logEntries.Add(line);
            }

            logEntries.Add(message); //Add the user's message to the end of the list


            if (logEntries.Count > 300) //Remove the oldest message if the log goes over 300 items
            {
                logEntries.RemoveAt(0); //oldest message 
            }

            StreamWriter outFile = new StreamWriter(DB_LOG);

            //rewrite each string into the log file from order of oldest to newest
            foreach (string line in logEntries)
            {
                outFile.WriteLine(line);
            }

            outFile.Close();
        }
    }
}
