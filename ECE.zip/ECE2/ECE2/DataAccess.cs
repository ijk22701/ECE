﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace ECE2
{
    public class DataAccess
    {

        ////////////////////////////////Queries////////////////////////////////
        

        /// <summary>
        /// Gets an item by ID from the database
        /// </summary>
        /// <param name="id">The ID of the item you want to retrieve</param>
        /// <returns>The item packaged within a list of type Item</returns>
        public List<Item> GetItem(string id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<Item>("dbo.Item_GetByID @ID", new { ID = id }).ToList();
                return output;
            }
        }

        /// <summary>
        /// Returns all the kits in the database
        /// </summary>
        /// <returns>A list of type Kit containing all the kits in the database</returns>
        public List<Kit> GetAllKits()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<Kit>("dbo.Kit_PrintAll").ToList();
                return output;
            }
        }

        /// <summary>
        /// Gets all the items in a kit 
        /// </summary>
        /// <param name="kitName">The name of the kit you want to retrieve items from</param>
        /// <returns>A list of type Item containing all the items in the kit</returns>
        public List<Item> GetItemByKit(string kitName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<Item>("dbo.Item_GetByKitName @KitName", new { KitName = kitName }).ToList();
                return output;
            }
        }

        /// <summary>
        /// Gets all items from the database, the name "print" is misleading. 
        /// </summary>
        /// <returns>A list of all the items in the database</returns>
        public List<Item> PrintAllItems()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<Item>("dbo.Item_PrintAll").ToList();
                return output;
            }
        }

        /// <summary>
        /// Gets all the kit items from a kit (different format than normal items)
        /// </summary>
        /// <param name="kitName">The kit you want to retrieve kit items from</param>
        /// <returns>A list of type KitItem representing all the kit items in the specified kit</returns>
        public List<KitItem> GetKitItemInfo(string kitName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<KitItem>("dbo.GetKitItemInfo @KitName", new {Kitname = kitName}).ToList();
                return output;
            }
        }

        /// <summary>
        /// Retrieves all the quantities of each item from a list in the same order as the items appear in that kit
        /// </summary>
        /// <param name="kitName">The name of the kit you want to retrieve quantities from</param>
        /// <returns>A list of type string that contains the quantities of every item in a kit. The list is 1 to 1 with a normal item list from the same kit</returns>
        public List<string> GetItemQuantityFromKit(string kitName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<string>("dbo.GetQuantitesFromKit @KitName", new { Kitname = kitName }).ToList();
                return output;
            }
        }

        /// <summary>
        /// Retrieves the information for all the users in the database
        /// </summary>
        /// <returns>A list of type User containing all the users in the database</returns>
        public List<User> GetUserList()
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<User>("dbo.GetUserList").ToList();
                return output;
            }
        }

        /// <summary>
        /// Gets a user by their username from the database
        /// </summary>
        /// <param name="username">The username of the user you wish to retrieve</param>
        /// <returns>The user that was searched for, packaged into a list of type User</returns>
        public List<User> GetUserByName(string username)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                var output = connection.Query<User>("dbo.GetUserByName @username", new {username = username}).ToList();
                return output;
            }
        }

        ////////////////////////////////Executions////////////////////////////////

        /// <summary>
        /// Adds a list of items to the database
        /// </summary>
        /// <param name="items">The list of items you wish to add to the database</param>
        public void AddItem(List<Item> items)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {             
                connection.Execute("dbo.Item_Add @ID, @name, @description, @quantity, @instock", items);
            }
        }

        /// <summary>
        /// Deletes an item from the database by ID
        /// </summary>
        /// <param name="id">The ID of the item you wish to delete</param>
        public void DeleteItem(int id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                
                connection.Execute("dbo.Item_Delete @ID", new { ID = id});
            }
        }

        /// <summary>
        /// Adds a kit to the database
        /// </summary>
        /// <param name="kitName">The name of the kit you are adding</param>
        /// <param name="kitDescription">The description of the kit you are adding</param>
        public void AddKit(string kitName, string kitDescription)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                List<Kit> kits = new List<Kit>();
                kits.Add(new Kit { name = kitName, description = kitDescription } );
                connection.Execute("dbo.Create_Kit @name, @description", kits);
            }
        }

        /// <summary>
        /// Adds an item to a kit
        /// </summary>
        /// <param name="kitName">The name of the kit you wish to add to</param>
        /// <param name="id">The ID of the item you wish to add</param>
        /// <param name="quantity">The amount of that item you want in the kit</param>
        public void AddToKit(string kitName, string id, string quantity)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                List<KitItem> itemInfo = new List<KitItem>();
                itemInfo.Add(new KitItem { KitName = kitName, ID = id, Quantity = quantity });
                connection.Execute("dbo.AddToKit @Kitname, @ID, @Quantity", itemInfo);
            }
        }

        /// <summary>
        /// Deletes an item from a kit
        /// </summary>
        /// <param name="kitName">The name of the kit you wish to delete from</param>
        /// <param name="id">The ID of the item you wish to delete</param>
        public void DeleteFromKit(string kitName, string id)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                List<KitItem> itemInfo = new List<KitItem>();
                itemInfo.Add(new KitItem { KitName = kitName, ID = id});
                connection.Execute("dbo.RemoveFromKit @Kitname, @ID", itemInfo);
            }
        }

        /// <summary>
        /// Deletes a kt
        /// </summary>
        /// <param name="kitName">The name of the kit you wish to delete</param>
        public void DeleteKit(string kitName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                connection.Execute("dbo.RemoveKit @Kitname", new { Kitname = kitName });
            }
        }

        /// <summary>
        /// Adds a user to the database
        /// </summary>
        /// <param name="newUser">The user you wish to add to the database</param>
        public void AddUser(User newUser)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                List<User> newUsers = new List<User>();
                newUsers.Add(newUser);
                connection.Execute("dbo.AddUser @username, @password, @adminRoll", newUsers);
            }
        }
        
        /// <summary>
        /// Deletes a user from the database
        /// </summary>
        /// <param name="username">The username of the user you wish to delete</param>
        public void DeleteUser(string username)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(Helper.CnnVal("ECEDB")))
            {
                connection.Execute("dbo.DeleteUser @username", new { username = username});
            }
        }
    }
}
