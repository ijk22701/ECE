﻿namespace ECE2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.UpdateItems = new System.Windows.Forms.Button();
            this.KitOptions = new System.Windows.Forms.Button();
            this.KitListBox = new System.Windows.Forms.ListBox();
            this.ItemBox = new System.Windows.Forms.ListBox();
            this.CheckoutOptions = new System.Windows.Forms.Button();
            this.UserConfig = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.UsernameDisplayBox = new System.Windows.Forms.TextBox();
            this.SignOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(434, 176);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(882, 86);
            this.button1.TabIndex = 10;
            this.button1.Text = "Add/Delete Items";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // exit
            // 
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exit.Location = new System.Drawing.Point(1125, 12);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(191, 86);
            this.exit.TabIndex = 11;
            this.exit.Text = "Exit";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // UpdateItems
            // 
            this.UpdateItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateItems.Location = new System.Drawing.Point(434, 268);
            this.UpdateItems.Name = "UpdateItems";
            this.UpdateItems.Size = new System.Drawing.Size(882, 86);
            this.UpdateItems.TabIndex = 12;
            this.UpdateItems.Text = "Update Items";
            this.UpdateItems.UseVisualStyleBackColor = true;
            this.UpdateItems.Click += new System.EventHandler(this.UpdateItems_Click);
            // 
            // KitOptions
            // 
            this.KitOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitOptions.Location = new System.Drawing.Point(12, 268);
            this.KitOptions.Name = "KitOptions";
            this.KitOptions.Size = new System.Drawing.Size(378, 86);
            this.KitOptions.TabIndex = 13;
            this.KitOptions.Text = "Kit Options";
            this.KitOptions.UseVisualStyleBackColor = true;
            this.KitOptions.Click += new System.EventHandler(this.KitOptions_Click);
            // 
            // KitListBox
            // 
            this.KitListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitListBox.FormattingEnabled = true;
            this.KitListBox.ItemHeight = 24;
            this.KitListBox.Location = new System.Drawing.Point(12, 360);
            this.KitListBox.Name = "KitListBox";
            this.KitListBox.Size = new System.Drawing.Size(378, 820);
            this.KitListBox.TabIndex = 6;
            // 
            // ItemBox
            // 
            this.ItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBox.FormattingEnabled = true;
            this.ItemBox.ItemHeight = 24;
            this.ItemBox.Location = new System.Drawing.Point(434, 360);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(882, 820);
            this.ItemBox.TabIndex = 0;
            // 
            // CheckoutOptions
            // 
            this.CheckoutOptions.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckoutOptions.Location = new System.Drawing.Point(12, 176);
            this.CheckoutOptions.Name = "CheckoutOptions";
            this.CheckoutOptions.Size = new System.Drawing.Size(378, 86);
            this.CheckoutOptions.TabIndex = 14;
            this.CheckoutOptions.Text = "Checkout Kits/Parts";
            this.CheckoutOptions.UseVisualStyleBackColor = true;
            this.CheckoutOptions.Click += new System.EventHandler(this.button2_Click);
            // 
            // UserConfig
            // 
            this.UserConfig.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserConfig.Location = new System.Drawing.Point(928, 12);
            this.UserConfig.Name = "UserConfig";
            this.UserConfig.Size = new System.Drawing.Size(191, 86);
            this.UserConfig.TabIndex = 15;
            this.UserConfig.Text = "User Config";
            this.UserConfig.UseVisualStyleBackColor = true;
            this.UserConfig.Click += new System.EventHandler(this.UserConfig_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "Logged in as:";
            // 
            // UsernameDisplayBox
            // 
            this.UsernameDisplayBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameDisplayBox.Location = new System.Drawing.Point(12, 41);
            this.UsernameDisplayBox.Name = "UsernameDisplayBox";
            this.UsernameDisplayBox.ReadOnly = true;
            this.UsernameDisplayBox.Size = new System.Drawing.Size(378, 31);
            this.UsernameDisplayBox.TabIndex = 18;
            // 
            // SignOut
            // 
            this.SignOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SignOut.Location = new System.Drawing.Point(1125, 104);
            this.SignOut.Name = "SignOut";
            this.SignOut.Size = new System.Drawing.Size(191, 66);
            this.SignOut.TabIndex = 19;
            this.SignOut.Text = "Sign Out";
            this.SignOut.UseVisualStyleBackColor = true;
            this.SignOut.Click += new System.EventHandler(this.SignOut_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 1188);
            this.Controls.Add(this.SignOut);
            this.Controls.Add(this.UsernameDisplayBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UserConfig);
            this.Controls.Add(this.CheckoutOptions);
            this.Controls.Add(this.KitOptions);
            this.Controls.Add(this.UpdateItems);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.KitListBox);
            this.Controls.Add(this.ItemBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Button UpdateItems;
        private System.Windows.Forms.Button KitOptions;
        private System.Windows.Forms.ListBox KitListBox;
        private System.Windows.Forms.ListBox ItemBox;
        private System.Windows.Forms.Button CheckoutOptions;
        private System.Windows.Forms.Button UserConfig;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox UsernameDisplayBox;
        private System.Windows.Forms.Button SignOut;
    }
}

