﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ECE2
{
    public partial class CheckoutSystem : Form
    {
        User activeUser = new User(); //The user signed in to the program
        public Kit currentKit = new Kit(); //the kit being modified 
        public Item currentItem = new Item(); //the item being modified
        public KitItem currentKitItem = new KitItem(); //a list of object KitItem used to get quantities in kit
        public List<Kit> kits = new List<Kit>(); //a list of all kits in the database
        public List<Item> items = new List<Item>(); //a list of all items in the database
        private List<Item> itemsInCurrentKit = new List<Item>(); //all the items in the selected kit
        private List<string> errorList = new List<string>(); //A list of errors in the program, refreshed every button click
        private const string DB_LOG = "DB_LOG.txt"; //The name of the text file for the event log

        /// <summary>
        /// A constructor for the CheckoutSystem form
        /// </summary>
        /// <param name="ActiveUser">The user signed in to the program</param>
        public CheckoutSystem(User ActiveUser)
        {
            activeUser = ActiveUser;
            InitializeComponent();
            UpdateBinding();
        }

        /// <summary>
        /// Refreshes the program to it's normal state
        /// </summary>
        public void UpdateBinding()
        {
            DataAccess db = new DataAccess(); //create a DataAccess class
            kits = db.GetAllKits(); //fill kits with all the kits in the database
            items = db.PrintAllItems(); //fill items with all the items in the database
            currentKitItem = new KitItem(); //clear currentKitItem
            currentKit = new Kit(); //clear currentKit
            KitBox.DataSource = kits; 
            KitBox.DisplayMember = "printOut";
            ItemBox.DataSource= items;
            ItemBox.DisplayMember = "BasicInfo";
            checkOutQuantityBox.Text = "1"; //Put a 1 in check out quantity since you don't need to check out less than that
            ItemIDBox.Text = ""; 
            KitNameBox.Text = "";

            //the items below are hidden on refresh to improve UX
            CheckOutItem.Hide();
            CheckInItem.Hide();
            CheckOutKit.Hide();
            CheckInKit.Hide();
            checkoutQuantityLabel.Hide();
            checkOutQuantityBox.Hide();
        }


        private void ItemAddBack_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(activeUser);
            this.Hide();
            form.ShowDialog();
        }

        private void SelectItem_Click(object sender, EventArgs e)
        {
            errorList.Clear(); //Clear the error list of any previous errors
            bool exists = false; //Whether or not the item entered by the user exists
            DataAccess db = new DataAccess();

            foreach (Item item in items) //cycle through all item objects in the items list
            {
                if (item.ID == ItemIDBox.Text) //check if the ID of item matches what the user entered
                {
                    //show the options for check in/out
                    CheckOutItem.Show();
                    CheckInItem.Show();

                    List<Item> resultsOfSearch = db.GetItem(ItemIDBox.Text); //GetItem returns a list containing one item
                    currentItem = resultsOfSearch[0]; //display the only item from the search (index 0)
                    ItemBox.DataSource = resultsOfSearch; //show the item on ItemBox
                    ItemBox.DisplayMember = "BasicInfo";
                    exists = true; //An item exists, change exists to true
                    checkoutQuantityLabel.Show();
                    checkOutQuantityBox.Show();
                    break;
                }
            }
            if (!exists) //if the user entered ID does not exist
            { 
                errorList.Add("ID was not found on list");
                ItemBox.DataSource = errorList; //display the list of errors
            }
        }

        private void SelectKit_Click(object sender, EventArgs e)
        {
            bool exists = false; //whether or not the item exists
            DataAccess db = new DataAccess();
            errorList.Clear(); //clear the error list
            foreach (Kit kit in kits) //go through all kit objects in the kits list
            {
                if (kit.name == KitNameBox.Text) //if the user entered kit name matches the name of a kit object
                {
                    //show check in/out options for kits
                    CheckInKit.Show(); 
                    CheckOutKit.Show();

                    exists = true;//The kit exists, set to true

                    string[] searchResults = { KitNameBox.Text }; //Create an array containing only the user entered input, the stored procedure requires an array or list for input
                    itemsInCurrentKit = db.GetItemByKit(KitNameBox.Text); //fill the list of items in kit with the items in the selected user kit
                    KitBox.DataSource = searchResults; //display the items in the selected kit
                    List<string> quantities = db.GetItemQuantityFromKit(KitNameBox.Text); //get the list of quantities of all items in the kit in the same order as itemsInCurrentKit
                    List<string> quantitiesWithSearchResults = new List<string>(); //A list of strings that has both the quantities and names of items matched together
                    int i = 0; //a basic iterator

                    //Below loop combines the quantities of items with the BasicInfo string of the item and stores them in a list
                    foreach (string quantity in quantities)
                    {
                        quantitiesWithSearchResults.Add(quantity + " of item: " + itemsInCurrentKit[i].BasicInfo);
                        i++;
                    }

                    currentKit = kit; //sets current kit to the kit specified by the user
                    ItemBox.DataSource = quantitiesWithSearchResults; //Show the quantities with search results

                    break;
                }

            } if (!exists)
            {
                errorList.Add("Entry does not match an existing kit");
                ItemBox.DataSource = errorList;
            }
        }

        //all this method does is refresh the page
        private void ClearSearchOrErrors_Click(object sender, EventArgs e)
        {
            UpdateBinding();
        }

        private void CheckOutItem_Click(object sender, EventArgs e)
        {
            errorList.Clear(); //clear error lsit
            DataAccess db = new DataAccess();
            if (int.TryParse(checkOutQuantityBox.Text, out int checkOutQuantity)) //check if quantity is an integer
            {
                if (currentItem.Name != "") //check if name isn't empty (it shouldn't be possible but it's here just in case)
                {
                    if (currentItem.InStock >= checkOutQuantity && checkOutQuantity > 0) //Make sure quantity is lower than the in-stock and greater than zero
                    {
                        currentItem.InStock = currentItem.InStock - checkOutQuantity; //subtract in stock from what the user checked out
                        db.DeleteItem(int.Parse(currentItem.ID)); //delete the item for the purpose of replacing it
                        db.AddItem(new List<Item> { currentItem } ); //replace the item with the new in-stock number
                        WriteToLogFile($">>> {activeUser.UserName} checked out {checkOutQuantity} {currentItem.Name} at {DateTime.Now}"); //write this string to the log file
                        UpdateBinding(); 
                    } else
                    {
                        errorList.Add("Item quantity must be less than current stock");
                        ItemBox.DataSource = errorList;
                    }
                }
                else
                {
                    errorList.Add("No item selected");
                    ItemBox.DataSource = errorList;
                }
            }
        }

        /// <summary>
        /// Writes the string sent to it into the log file
        /// </summary>
        /// <param name="message">The message sent to the log file</param>
        private void WriteToLogFile(string message)
        {
            List<string> logEntries = new List<string>(); //Every string in this list is a line on the log file

            //Add each line in the log file as a string into the logEntries list since they will be deleted when the file is written to
            foreach (string line in System.IO.File.ReadLines(DB_LOG))
            {
                logEntries.Add(line);
            }

            logEntries.Add(message); //Add the user's message to the end of the list


            if (logEntries.Count > 300) //Remove the oldest message if the log goes over 300 items
            {
                logEntries.RemoveAt(0); //oldest message 
            }

            StreamWriter outFile = new StreamWriter(DB_LOG);

            //rewrite each string into the log file from order of oldest to newest
            foreach (string line in logEntries)
            {
                outFile.WriteLine(line);
            }

            outFile.Close();
        }

        private void CheckInItem_Click(object sender, EventArgs e)
        {
            errorList.Clear(); //clear error list
            DataAccess db = new DataAccess();
            if (int.TryParse(checkOutQuantityBox.Text, out int checkInQuantity)) //make sure quantity is an integer, out checkInQuantity is the amount the user wants to check in. 
            {
                if (currentItem.Name != "") //make sure entered name isn't empty
                {
                    if (currentItem.InStock + checkInQuantity <= currentItem.Quantity && checkInQuantity > 0) //check if the current stock plus check in quantity is less than total quantity
                    {
                        currentItem.InStock = currentItem.InStock + checkInQuantity; //change instock on current item to add the amount the user checked in
                        db.DeleteItem(int.Parse(currentItem.ID)); //delete the item in the database so that it can be re-added with the new in-stock number
                        db.AddItem(new List<Item> { currentItem }); //re-add item
                        WriteToLogFile($"<<< {activeUser.UserName} checked in {checkInQuantity} {currentItem.Name}, {currentItem.ID} at {DateTime.Now}"); //write to log file
                        UpdateBinding();
                    }
                    else
                    {
                        errorList.Add("Instock cannot exceed quantity, check in quantity cannot be zero");
                        ItemBox.DataSource = errorList;
                    }
                }
                else
                {
                    errorList.Add("No item selected");
                    ItemBox.DataSource = errorList;
                }
            }
        }

        private void CheckOutKit_Click(object sender, EventArgs e)
        {
            errorList.Clear(); //clear error lsit
            DataAccess db = new DataAccess();
            if (int.TryParse(checkOutQuantityBox.Text, out int checkOutQuantity)) //make sure user entered quantity is an integer, out checkOutQuantity is the number the user wants to check out
            {
                if (currentKit.name != "") //make sure current kit name isn't empty
                {
                    List<string> quantities = db.GetItemQuantityFromKit(currentKit.name); //get the number of quantities for the item in the selected kit
                    List<int> quantitiesToInt = new List<int>(); //convert quantities to integer since they are of type string

                    //this loop changes the quantities to type integer
                    foreach (string quantity in quantities)
                    {
                        quantitiesToInt.Add(int.Parse(quantity));
                    }

                    int i = 0; //an iterator
                    bool inStock = true; //true if all the items in the list are in stock

                    //go through all the items in the current kit
                    foreach (Item item in itemsInCurrentKit)
                    {
                        if (item.InStock - quantitiesToInt[i]< 0) //If the current item does not have enough in-stock to check out the currently selected kit
                        {
                            inStock = false; //change in-stock to false since the kit is not in-stock
                            errorList.Add("Not all items in kit have enough stock to check out this kit");
                            ItemBox.DataSource = errorList;
                        }
                    }
                    if (inStock)
                    {
                        int j = 0; //another iterator

                        //for all the items in the seleccted kit
                        foreach (Item item in itemsInCurrentKit) {
                            item.InStock = item.InStock - quantitiesToInt[j]; //subtract their stock from the amount specified in the kit
                            db.DeleteItem(int.Parse(item.ID)); //delete the item for the purpose of updating it
                            db.AddItem(new List<Item> { item }); //replace the item with the new in-stock number
                            WriteToLogFile($">>> {activeUser.UserName} checked out {quantitiesToInt[j]} {item.Name}, ID {item.ID}, at {DateTime.Now}"); //write to log file
                            UpdateBinding();
                        }
                    }
                }
                else
                {
                    errorList.Add("No item selected");
                    ItemBox.DataSource = errorList;
                }
            }
        }

        private void CheckInKit_Click(object sender, EventArgs e)
        {
            errorList.Clear(); //clear error list
            DataAccess db = new DataAccess();
            if (int.TryParse(checkOutQuantityBox.Text, out int checkOutQuantity)) //make sure user entered quantity is an integer, out checkOutQuantity is the number the user wants to check in
            {
                if (currentKit.name != "") //make sure current kit name isn't empty
                {
                    List<string> quantities = db.GetItemQuantityFromKit(currentKit.name); //get the quantities of the items in the kit
                    List<int> quantitiesToInt = new List<int>(); //convert the quantities to integer since they are type string
                    
                    //this loop converts the quantities to type integer
                    foreach (string quantity in quantities)
                    {
                        quantitiesToInt.Add(int.Parse(quantity));
                    }

                    int j = 0; //an iterator

                    //for each item in the current kit
                    foreach (Item item in itemsInCurrentKit)
                    {
                        item.InStock = item.InStock + quantitiesToInt[j]; //add the quantity of the item in the kit to the instock value of the item
                        db.DeleteItem(int.Parse(item.ID)); //delete the item for the purpose of updating it
                        db.AddItem(new List<Item> { item }); //replace the item
                        WriteToLogFile($"<<< {activeUser.UserName} checked in {quantitiesToInt[j]} {item.Name}, ID {item.ID}, at {DateTime.Now}"); //write to log
                        UpdateBinding();
                    }
                    
                }
                else
                {
                    errorList.Add("No item selected");
                    ItemBox.DataSource = errorList;
                }
            }
        }
    }
}
