﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com
///
///
///CheckoutSystem.cs has the most detailed commenting, the rest of the files are more simplified to avoid repetition.
///Refer to CheckoutSystem.cs for the most detail on how many of the functions work. 


using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ECE2
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            bool loginEnabled = true; //set to true to enable login, set to false to disable login

            if (loginEnabled)
            {
                Application.Run(new LoginPage()); //run the normal login page

            } else
            {
                User userSystemDisabled = new User();

                userSystemDisabled.UserName = "userSystemDisabled"; //this will replace a normal user when the login is disabled since the user system is heavily connected to the rest of the program
                userSystemDisabled.Password = "test";
                userSystemDisabled.AdminRoll = "a";

                Application.Run(new Form1(userSystemDisabled));

            }
        }
    }
}
