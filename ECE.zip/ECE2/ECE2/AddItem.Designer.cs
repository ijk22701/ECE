﻿namespace ECE2
{
    partial class AddItem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ItemAddName = new System.Windows.Forms.TextBox();
            this.ItemAddDescription = new System.Windows.Forms.TextBox();
            this.ItemAddQuantity = new System.Windows.Forms.TextBox();
            this.ItemAddInstock = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ItemBox = new System.Windows.Forms.ListBox();
            this.ItemAddAdd = new System.Windows.Forms.Button();
            this.ItemAddBack = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.IDForDelete = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Commit_List = new System.Windows.Forms.Button();
            this.ClearError = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ItemAddName
            // 
            this.ItemAddName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddName.Location = new System.Drawing.Point(271, 21);
            this.ItemAddName.Name = "ItemAddName";
            this.ItemAddName.Size = new System.Drawing.Size(998, 31);
            this.ItemAddName.TabIndex = 0;
            // 
            // ItemAddDescription
            // 
            this.ItemAddDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddDescription.Location = new System.Drawing.Point(271, 145);
            this.ItemAddDescription.Name = "ItemAddDescription";
            this.ItemAddDescription.Size = new System.Drawing.Size(998, 31);
            this.ItemAddDescription.TabIndex = 4;
            // 
            // ItemAddQuantity
            // 
            this.ItemAddQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddQuantity.Location = new System.Drawing.Point(271, 61);
            this.ItemAddQuantity.Name = "ItemAddQuantity";
            this.ItemAddQuantity.Size = new System.Drawing.Size(998, 31);
            this.ItemAddQuantity.TabIndex = 7;
            // 
            // ItemAddInstock
            // 
            this.ItemAddInstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddInstock.Location = new System.Drawing.Point(271, 104);
            this.ItemAddInstock.Name = "ItemAddInstock";
            this.ItemAddInstock.Size = new System.Drawing.Size(998, 31);
            this.ItemAddInstock.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(97, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Item Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(97, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 25);
            this.label2.TabIndex = 10;
            this.label2.Text = "Item Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(97, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 25);
            this.label3.TabIndex = 11;
            this.label3.Text = "Item Stock";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(97, 145);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Item Description";
            // 
            // ItemBox
            // 
            this.ItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBox.FormattingEnabled = true;
            this.ItemBox.ItemHeight = 25;
            this.ItemBox.Location = new System.Drawing.Point(99, 283);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(1170, 579);
            this.ItemBox.TabIndex = 12;
            // 
            // ItemAddAdd
            // 
            this.ItemAddAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddAdd.Location = new System.Drawing.Point(99, 198);
            this.ItemAddAdd.Name = "ItemAddAdd";
            this.ItemAddAdd.Size = new System.Drawing.Size(136, 49);
            this.ItemAddAdd.TabIndex = 13;
            this.ItemAddAdd.Text = "Add Item";
            this.ItemAddAdd.UseVisualStyleBackColor = true;
            this.ItemAddAdd.Click += new System.EventHandler(this.ItemAddAdd_Click);
            // 
            // ItemAddBack
            // 
            this.ItemAddBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddBack.Location = new System.Drawing.Point(99, 914);
            this.ItemAddBack.Name = "ItemAddBack";
            this.ItemAddBack.Size = new System.Drawing.Size(212, 87);
            this.ItemAddBack.TabIndex = 14;
            this.ItemAddBack.Text = "Home";
            this.ItemAddBack.UseVisualStyleBackColor = true;
            this.ItemAddBack.Click += new System.EventHandler(this.ItemAddBack_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(981, 952);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(288, 49);
            this.button1.TabIndex = 15;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // IDForDelete
            // 
            this.IDForDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDForDelete.Location = new System.Drawing.Point(982, 914);
            this.IDForDelete.Name = "IDForDelete";
            this.IDForDelete.Size = new System.Drawing.Size(287, 31);
            this.IDForDelete.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1124, 886);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 25);
            this.label5.TabIndex = 17;
            this.label5.Text = "ID for deletion";
            // 
            // Commit_List
            // 
            this.Commit_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Commit_List.Location = new System.Drawing.Point(271, 198);
            this.Commit_List.Name = "Commit_List";
            this.Commit_List.Size = new System.Drawing.Size(152, 49);
            this.Commit_List.TabIndex = 18;
            this.Commit_List.Text = "Commit";
            this.Commit_List.UseVisualStyleBackColor = true;
            this.Commit_List.Click += new System.EventHandler(this.Commit_List_Click);
            // 
            // ClearError
            // 
            this.ClearError.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearError.Location = new System.Drawing.Point(1117, 198);
            this.ClearError.Name = "ClearError";
            this.ClearError.Size = new System.Drawing.Size(152, 49);
            this.ClearError.TabIndex = 19;
            this.ClearError.Text = "Clear Error";
            this.ClearError.UseVisualStyleBackColor = true;
            this.ClearError.Click += new System.EventHandler(this.ClearError_Click);
            // 
            // AddItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1336, 1026);
            this.Controls.Add(this.ClearError);
            this.Controls.Add(this.Commit_List);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.IDForDelete);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.ItemAddBack);
            this.Controls.Add(this.ItemAddAdd);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ItemAddInstock);
            this.Controls.Add(this.ItemAddQuantity);
            this.Controls.Add(this.ItemAddDescription);
            this.Controls.Add(this.ItemAddName);
            this.Name = "AddItem";
            this.Text = "AddItem";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ItemAddName;
        private System.Windows.Forms.TextBox ItemAddDescription;
        private System.Windows.Forms.TextBox ItemAddQuantity;
        private System.Windows.Forms.TextBox ItemAddInstock;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox ItemBox;
        private System.Windows.Forms.Button ItemAddAdd;
        private System.Windows.Forms.Button ItemAddBack;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox IDForDelete;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Commit_List;
        private System.Windows.Forms.Button ClearError;
    }
}