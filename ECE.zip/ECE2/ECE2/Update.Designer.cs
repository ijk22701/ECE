﻿namespace ECE2
{
    partial class Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClearError = new System.Windows.Forms.Button();
            this.ItemAddBack = new System.Windows.Forms.Button();
            this.UpdateItemButton = new System.Windows.Forms.Button();
            this.ItemBox = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ItemAddInstock = new System.Windows.Forms.TextBox();
            this.ItemAddQuantity = new System.Windows.Forms.TextBox();
            this.ItemAddDescription = new System.Windows.Forms.TextBox();
            this.ItemAddName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.IdSearchBox = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ClearError
            // 
            this.ClearError.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearError.Location = new System.Drawing.Point(1042, 266);
            this.ClearError.Name = "ClearError";
            this.ClearError.Size = new System.Drawing.Size(152, 49);
            this.ClearError.TabIndex = 35;
            this.ClearError.Text = "Clear Error";
            this.ClearError.UseVisualStyleBackColor = true;
            this.ClearError.Click += new System.EventHandler(this.ClearError_Click);
            // 
            // ItemAddBack
            // 
            this.ItemAddBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddBack.Location = new System.Drawing.Point(24, 913);
            this.ItemAddBack.Name = "ItemAddBack";
            this.ItemAddBack.Size = new System.Drawing.Size(212, 87);
            this.ItemAddBack.TabIndex = 30;
            this.ItemAddBack.Text = "Home";
            this.ItemAddBack.UseVisualStyleBackColor = true;
            this.ItemAddBack.Click += new System.EventHandler(this.ItemAddBack_Click);
            // 
            // UpdateItemButton
            // 
            this.UpdateItemButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateItemButton.Location = new System.Drawing.Point(24, 266);
            this.UpdateItemButton.Name = "UpdateItemButton";
            this.UpdateItemButton.Size = new System.Drawing.Size(136, 49);
            this.UpdateItemButton.TabIndex = 29;
            this.UpdateItemButton.Text = "Update Item";
            this.UpdateItemButton.UseVisualStyleBackColor = true;
            this.UpdateItemButton.Click += new System.EventHandler(this.UpdateItemButton_Click);
            // 
            // ItemBox
            // 
            this.ItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBox.FormattingEnabled = true;
            this.ItemBox.ItemHeight = 25;
            this.ItemBox.Location = new System.Drawing.Point(24, 332);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(1170, 554);
            this.ItemBox.TabIndex = 28;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 25);
            this.label4.TabIndex = 26;
            this.label4.Text = "Item Description";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 25);
            this.label3.TabIndex = 27;
            this.label3.Text = "Item Stock";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 25);
            this.label2.TabIndex = 25;
            this.label2.Text = "Item Quantity";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 25);
            this.label1.TabIndex = 24;
            this.label1.Text = "Item Name";
            // 
            // ItemAddInstock
            // 
            this.ItemAddInstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddInstock.Location = new System.Drawing.Point(193, 171);
            this.ItemAddInstock.Name = "ItemAddInstock";
            this.ItemAddInstock.Size = new System.Drawing.Size(998, 31);
            this.ItemAddInstock.TabIndex = 23;
            // 
            // ItemAddQuantity
            // 
            this.ItemAddQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddQuantity.Location = new System.Drawing.Point(193, 128);
            this.ItemAddQuantity.Name = "ItemAddQuantity";
            this.ItemAddQuantity.Size = new System.Drawing.Size(998, 31);
            this.ItemAddQuantity.TabIndex = 22;
            // 
            // ItemAddDescription
            // 
            this.ItemAddDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddDescription.Location = new System.Drawing.Point(193, 212);
            this.ItemAddDescription.Name = "ItemAddDescription";
            this.ItemAddDescription.Size = new System.Drawing.Size(998, 31);
            this.ItemAddDescription.TabIndex = 21;
            // 
            // ItemAddName
            // 
            this.ItemAddName.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddName.Location = new System.Drawing.Point(193, 88);
            this.ItemAddName.Name = "ItemAddName";
            this.ItemAddName.Size = new System.Drawing.Size(998, 31);
            this.ItemAddName.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 25);
            this.label5.TabIndex = 36;
            this.label5.Text = "Item ID";
            // 
            // IdSearchBox
            // 
            this.IdSearchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdSearchBox.Location = new System.Drawing.Point(193, 38);
            this.IdSearchBox.Name = "IdSearchBox";
            this.IdSearchBox.Size = new System.Drawing.Size(308, 31);
            this.IdSearchBox.TabIndex = 37;
            // 
            // SearchButton
            // 
            this.SearchButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchButton.Location = new System.Drawing.Point(525, 38);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(136, 31);
            this.SearchButton.TabIndex = 38;
            this.SearchButton.Text = "Search Item";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1217, 1021);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.IdSearchBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ClearError);
            this.Controls.Add(this.ItemAddBack);
            this.Controls.Add(this.UpdateItemButton);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ItemAddInstock);
            this.Controls.Add(this.ItemAddQuantity);
            this.Controls.Add(this.ItemAddDescription);
            this.Controls.Add(this.ItemAddName);
            this.Name = "Update";
            this.Text = "Update";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ClearError;
        private System.Windows.Forms.Button ItemAddBack;
        private System.Windows.Forms.Button UpdateItemButton;
        private System.Windows.Forms.ListBox ItemBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ItemAddInstock;
        private System.Windows.Forms.TextBox ItemAddQuantity;
        private System.Windows.Forms.TextBox ItemAddDescription;
        private System.Windows.Forms.TextBox ItemAddName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox IdSearchBox;
        private System.Windows.Forms.Button SearchButton;
    }
}