﻿namespace ECE2
{
    partial class User_config
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ItemAddBack = new System.Windows.Forms.Button();
            this.userBox = new System.Windows.Forms.ListBox();
            this.UsernameEntry = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.PasswordEntryBox = new System.Windows.Forms.TextBox();
            this.adminBox = new System.Windows.Forms.CheckBox();
            this.AddUser = new System.Windows.Forms.Button();
            this.UpdateUser = new System.Windows.Forms.Button();
            this.DeleteUser = new System.Windows.Forms.Button();
            this.SelectUser = new System.Windows.Forms.Button();
            this.ClearError = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ItemAddBack
            // 
            this.ItemAddBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddBack.Location = new System.Drawing.Point(12, 779);
            this.ItemAddBack.Name = "ItemAddBack";
            this.ItemAddBack.Size = new System.Drawing.Size(206, 87);
            this.ItemAddBack.TabIndex = 31;
            this.ItemAddBack.Text = "Home";
            this.ItemAddBack.UseVisualStyleBackColor = true;
            this.ItemAddBack.Click += new System.EventHandler(this.ItemAddBack_Click);
            // 
            // userBox
            // 
            this.userBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userBox.FormattingEnabled = true;
            this.userBox.ItemHeight = 25;
            this.userBox.Location = new System.Drawing.Point(17, 152);
            this.userBox.Name = "userBox";
            this.userBox.Size = new System.Drawing.Size(1063, 604);
            this.userBox.TabIndex = 32;
            // 
            // UsernameEntry
            // 
            this.UsernameEntry.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameEntry.Location = new System.Drawing.Point(151, 12);
            this.UsernameEntry.Name = "UsernameEntry";
            this.UsernameEntry.Size = new System.Drawing.Size(373, 31);
            this.UsernameEntry.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 25);
            this.label1.TabIndex = 34;
            this.label1.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 35;
            this.label2.Text = "Password";
            // 
            // PasswordEntryBox
            // 
            this.PasswordEntryBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordEntryBox.Location = new System.Drawing.Point(151, 59);
            this.PasswordEntryBox.Name = "PasswordEntryBox";
            this.PasswordEntryBox.Size = new System.Drawing.Size(373, 31);
            this.PasswordEntryBox.TabIndex = 36;
            // 
            // adminBox
            // 
            this.adminBox.AutoSize = true;
            this.adminBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminBox.Location = new System.Drawing.Point(12, 108);
            this.adminBox.Name = "adminBox";
            this.adminBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.adminBox.Size = new System.Drawing.Size(91, 29);
            this.adminBox.TabIndex = 37;
            this.adminBox.Text = "Admin";
            this.adminBox.UseVisualStyleBackColor = true;
            // 
            // AddUser
            // 
            this.AddUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddUser.Location = new System.Drawing.Point(530, 12);
            this.AddUser.Name = "AddUser";
            this.AddUser.Size = new System.Drawing.Size(133, 81);
            this.AddUser.TabIndex = 38;
            this.AddUser.Text = "Add User";
            this.AddUser.UseVisualStyleBackColor = true;
            this.AddUser.Click += new System.EventHandler(this.AddUser_Click);
            // 
            // UpdateUser
            // 
            this.UpdateUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateUser.Location = new System.Drawing.Point(808, 12);
            this.UpdateUser.Name = "UpdateUser";
            this.UpdateUser.Size = new System.Drawing.Size(133, 81);
            this.UpdateUser.TabIndex = 39;
            this.UpdateUser.Text = "Update User";
            this.UpdateUser.UseVisualStyleBackColor = true;
            this.UpdateUser.Click += new System.EventHandler(this.UpdateUser_Click);
            // 
            // DeleteUser
            // 
            this.DeleteUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteUser.Location = new System.Drawing.Point(947, 12);
            this.DeleteUser.Name = "DeleteUser";
            this.DeleteUser.Size = new System.Drawing.Size(133, 81);
            this.DeleteUser.TabIndex = 40;
            this.DeleteUser.Text = "Delete User";
            this.DeleteUser.UseVisualStyleBackColor = true;
            this.DeleteUser.Click += new System.EventHandler(this.DeleteUser_Click);
            // 
            // SelectUser
            // 
            this.SelectUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectUser.Location = new System.Drawing.Point(669, 12);
            this.SelectUser.Name = "SelectUser";
            this.SelectUser.Size = new System.Drawing.Size(133, 81);
            this.SelectUser.TabIndex = 41;
            this.SelectUser.Text = "Select User";
            this.SelectUser.UseVisualStyleBackColor = true;
            this.SelectUser.Click += new System.EventHandler(this.SelectUser_Click);
            // 
            // ClearError
            // 
            this.ClearError.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearError.Location = new System.Drawing.Point(874, 779);
            this.ClearError.Name = "ClearError";
            this.ClearError.Size = new System.Drawing.Size(206, 87);
            this.ClearError.TabIndex = 42;
            this.ClearError.Text = "Back/Clear Error";
            this.ClearError.UseVisualStyleBackColor = true;
            this.ClearError.Click += new System.EventHandler(this.ClearError_Click);
            // 
            // User_config
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 878);
            this.Controls.Add(this.ClearError);
            this.Controls.Add(this.SelectUser);
            this.Controls.Add(this.DeleteUser);
            this.Controls.Add(this.UpdateUser);
            this.Controls.Add(this.AddUser);
            this.Controls.Add(this.adminBox);
            this.Controls.Add(this.PasswordEntryBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UsernameEntry);
            this.Controls.Add(this.userBox);
            this.Controls.Add(this.ItemAddBack);
            this.Name = "User_config";
            this.Text = "User_config";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ItemAddBack;
        private System.Windows.Forms.ListBox userBox;
        private System.Windows.Forms.TextBox UsernameEntry;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox PasswordEntryBox;
        private System.Windows.Forms.CheckBox adminBox;
        private System.Windows.Forms.Button AddUser;
        private System.Windows.Forms.Button UpdateUser;
        private System.Windows.Forms.Button DeleteUser;
        private System.Windows.Forms.Button SelectUser;
        private System.Windows.Forms.Button ClearError;
    }
}