﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ECE2
{
    public partial class Form1 : Form
    {
        User activeUser = new User(); //the user currently signed in to the program
        List<Item> items = new List<Item>(); //list of all items
        List<Kit> kits = new List<Kit>(); //list of all kits

        /// <summary>
        /// A constructor for the form1 class
        /// </summary>
        /// <param name="ActiveUser">The user currently signed in to the program</param>
        public Form1(User ActiveUser)
        {
            activeUser = ActiveUser;
            InitializeComponent();
            DataAccess db = new DataAccess();
            kits = db.GetAllKits(); //fill kits list with all the kits in the database
            items = db.PrintAllItems(); //fill items with all the items in the database
            UpdateBinding();
            UsernameDisplayBox.Text = activeUser.UserName; //display the username of the signed in user

            //If the user is not an admin, the userconfig will be hidden.
            if (activeUser.AdminRoll != "a")
            {
                UserConfig.Hide();
            }
            if (activeUser.UserName == "userSystemDisabled")
            {
                SignOut.Hide();
            }
        }

        /// <summary>
        /// Refreshes the page to its starting state
        /// </summary>
        private void UpdateBinding()
        {
            ItemBox.DataSource = items;
            ItemBox.DisplayMember = "BasicInfo";
            KitListBox.DataSource = kits;
            KitListBox.DisplayMember = "printOut";
        }

        private void PrintAll_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            items = db.PrintAllItems();
            UpdateBinding();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddItem addItem = new AddItem(activeUser);
            addItem.ShowDialog();

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void UpdateItems_Click(object sender, EventArgs e)
        {
            Update updateItem = new Update(activeUser);
            this.Hide();
            updateItem.ShowDialog();
     
        }

        private void KitOptions_Click(object sender, EventArgs e)
        {
            CreateKit createKit = new CreateKit(activeUser);
            this.Hide();
            createKit.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e) //checkoutOptions
        {
            CheckoutSystem checkout = new CheckoutSystem(activeUser);
            this.Hide();
            checkout.ShowDialog();
        }

        private void UserConfig_Click(object sender, EventArgs e)
        {
            User_config config = new User_config(activeUser);
            this.Hide();
            config.ShowDialog();
        }

        private void SignOut_Click(object sender, EventArgs e)
        {
            LoginPage login = new LoginPage();
            this.Hide();
            login.ShowDialog();
        }
    }
}
