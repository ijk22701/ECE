﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE2
{
    public class KitItem
    {
        public string KitName { get; set; }
        public string ID { get; set; }
        public string Quantity { get; set; }

        public string printOut
        {
            get
            {
                return $"{Quantity}";
            }
        }
    }


}
