﻿namespace ECE2
{
    internal class Override
    {
    }
}