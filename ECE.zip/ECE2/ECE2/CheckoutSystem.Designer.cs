﻿namespace ECE2
{
    partial class CheckoutSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ItemAddBack = new System.Windows.Forms.Button();
            this.KitBox = new System.Windows.Forms.ListBox();
            this.ItemBox = new System.Windows.Forms.ListBox();
            this.KitNameBox = new System.Windows.Forms.TextBox();
            this.ItemIDBox = new System.Windows.Forms.TextBox();
            this.SelectKit = new System.Windows.Forms.Button();
            this.SelectItem = new System.Windows.Forms.Button();
            this.CheckInKit = new System.Windows.Forms.Button();
            this.CheckOutKit = new System.Windows.Forms.Button();
            this.CheckOutItem = new System.Windows.Forms.Button();
            this.CheckInItem = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ClearSearchOrErrors = new System.Windows.Forms.Button();
            this.checkOutQuantityBox = new System.Windows.Forms.TextBox();
            this.checkoutQuantityLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ItemAddBack
            // 
            this.ItemAddBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddBack.Location = new System.Drawing.Point(12, 1059);
            this.ItemAddBack.Name = "ItemAddBack";
            this.ItemAddBack.Size = new System.Drawing.Size(339, 87);
            this.ItemAddBack.TabIndex = 32;
            this.ItemAddBack.Text = "Home";
            this.ItemAddBack.UseVisualStyleBackColor = true;
            this.ItemAddBack.Click += new System.EventHandler(this.ItemAddBack_Click);
            // 
            // KitBox
            // 
            this.KitBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitBox.FormattingEnabled = true;
            this.KitBox.ItemHeight = 25;
            this.KitBox.Location = new System.Drawing.Point(13, 321);
            this.KitBox.Name = "KitBox";
            this.KitBox.Size = new System.Drawing.Size(371, 704);
            this.KitBox.TabIndex = 33;
            // 
            // ItemBox
            // 
            this.ItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBox.FormattingEnabled = true;
            this.ItemBox.HorizontalScrollbar = true;
            this.ItemBox.ItemHeight = 25;
            this.ItemBox.Location = new System.Drawing.Point(414, 321);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(879, 704);
            this.ItemBox.TabIndex = 34;
            // 
            // KitNameBox
            // 
            this.KitNameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitNameBox.Location = new System.Drawing.Point(121, 103);
            this.KitNameBox.Name = "KitNameBox";
            this.KitNameBox.Size = new System.Drawing.Size(263, 31);
            this.KitNameBox.TabIndex = 35;
            // 
            // ItemIDBox
            // 
            this.ItemIDBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemIDBox.Location = new System.Drawing.Point(121, 50);
            this.ItemIDBox.Name = "ItemIDBox";
            this.ItemIDBox.Size = new System.Drawing.Size(263, 31);
            this.ItemIDBox.TabIndex = 36;
            // 
            // SelectKit
            // 
            this.SelectKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectKit.Location = new System.Drawing.Point(414, 95);
            this.SelectKit.Name = "SelectKit";
            this.SelectKit.Size = new System.Drawing.Size(173, 47);
            this.SelectKit.TabIndex = 37;
            this.SelectKit.Text = "Select Kit";
            this.SelectKit.UseVisualStyleBackColor = true;
            this.SelectKit.Click += new System.EventHandler(this.SelectKit_Click);
            // 
            // SelectItem
            // 
            this.SelectItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectItem.Location = new System.Drawing.Point(414, 42);
            this.SelectItem.Name = "SelectItem";
            this.SelectItem.Size = new System.Drawing.Size(173, 47);
            this.SelectItem.TabIndex = 38;
            this.SelectItem.Text = "Select Item";
            this.SelectItem.UseVisualStyleBackColor = true;
            this.SelectItem.Click += new System.EventHandler(this.SelectItem_Click);
            // 
            // CheckInKit
            // 
            this.CheckInKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckInKit.Location = new System.Drawing.Point(772, 95);
            this.CheckInKit.Name = "CheckInKit";
            this.CheckInKit.Size = new System.Drawing.Size(173, 47);
            this.CheckInKit.TabIndex = 39;
            this.CheckInKit.Text = "Check In Kit";
            this.CheckInKit.UseVisualStyleBackColor = true;
            this.CheckInKit.Click += new System.EventHandler(this.CheckInKit_Click);
            // 
            // CheckOutKit
            // 
            this.CheckOutKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckOutKit.Location = new System.Drawing.Point(593, 95);
            this.CheckOutKit.Name = "CheckOutKit";
            this.CheckOutKit.Size = new System.Drawing.Size(173, 47);
            this.CheckOutKit.TabIndex = 40;
            this.CheckOutKit.Text = "Check Out Kit";
            this.CheckOutKit.UseVisualStyleBackColor = true;
            this.CheckOutKit.Click += new System.EventHandler(this.CheckOutKit_Click);
            // 
            // CheckOutItem
            // 
            this.CheckOutItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckOutItem.Location = new System.Drawing.Point(593, 42);
            this.CheckOutItem.Name = "CheckOutItem";
            this.CheckOutItem.Size = new System.Drawing.Size(173, 47);
            this.CheckOutItem.TabIndex = 41;
            this.CheckOutItem.Text = "Check Out Item";
            this.CheckOutItem.UseVisualStyleBackColor = true;
            this.CheckOutItem.Click += new System.EventHandler(this.CheckOutItem_Click);
            // 
            // CheckInItem
            // 
            this.CheckInItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckInItem.Location = new System.Drawing.Point(772, 42);
            this.CheckInItem.Name = "CheckInItem";
            this.CheckInItem.Size = new System.Drawing.Size(173, 47);
            this.CheckInItem.TabIndex = 42;
            this.CheckInItem.Text = "Check In Item";
            this.CheckInItem.UseVisualStyleBackColor = true;
            this.CheckInItem.Click += new System.EventHandler(this.CheckInItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 25);
            this.label1.TabIndex = 43;
            this.label1.Text = "Item ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(8, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 25);
            this.label2.TabIndex = 44;
            this.label2.Text = "Kit Name";
            // 
            // ClearSearchOrErrors
            // 
            this.ClearSearchOrErrors.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearSearchOrErrors.Location = new System.Drawing.Point(953, 43);
            this.ClearSearchOrErrors.Name = "ClearSearchOrErrors";
            this.ClearSearchOrErrors.Size = new System.Drawing.Size(283, 99);
            this.ClearSearchOrErrors.TabIndex = 45;
            this.ClearSearchOrErrors.Text = "Clear Selection and errors";
            this.ClearSearchOrErrors.UseVisualStyleBackColor = true;
            this.ClearSearchOrErrors.Click += new System.EventHandler(this.ClearSearchOrErrors_Click);
            // 
            // checkOutQuantityBox
            // 
            this.checkOutQuantityBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutQuantityBox.Location = new System.Drawing.Point(306, 153);
            this.checkOutQuantityBox.Name = "checkOutQuantityBox";
            this.checkOutQuantityBox.Size = new System.Drawing.Size(78, 31);
            this.checkOutQuantityBox.TabIndex = 46;
            // 
            // checkoutQuantityLabel
            // 
            this.checkoutQuantityLabel.AutoSize = true;
            this.checkoutQuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkoutQuantityLabel.Location = new System.Drawing.Point(7, 156);
            this.checkoutQuantityLabel.Name = "checkoutQuantityLabel";
            this.checkoutQuantityLabel.Size = new System.Drawing.Size(293, 25);
            this.checkoutQuantityLabel.TabIndex = 47;
            this.checkoutQuantityLabel.Text = "Check-out/Check-In Quantity:";
            // 
            // CheckoutSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1304, 1158);
            this.Controls.Add(this.checkoutQuantityLabel);
            this.Controls.Add(this.checkOutQuantityBox);
            this.Controls.Add(this.ClearSearchOrErrors);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CheckInItem);
            this.Controls.Add(this.CheckOutItem);
            this.Controls.Add(this.CheckOutKit);
            this.Controls.Add(this.CheckInKit);
            this.Controls.Add(this.SelectItem);
            this.Controls.Add(this.SelectKit);
            this.Controls.Add(this.ItemIDBox);
            this.Controls.Add(this.KitNameBox);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.KitBox);
            this.Controls.Add(this.ItemAddBack);
            this.Name = "CheckoutSystem";
            this.Text = "CheckoutSystem";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ItemAddBack;
        private System.Windows.Forms.ListBox KitBox;
        private System.Windows.Forms.ListBox ItemBox;
        private System.Windows.Forms.TextBox KitNameBox;
        private System.Windows.Forms.TextBox ItemIDBox;
        private System.Windows.Forms.Button SelectKit;
        private System.Windows.Forms.Button SelectItem;
        private System.Windows.Forms.Button CheckInKit;
        private System.Windows.Forms.Button CheckOutKit;
        private System.Windows.Forms.Button CheckOutItem;
        private System.Windows.Forms.Button CheckInItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ClearSearchOrErrors;
        private System.Windows.Forms.TextBox checkOutQuantityBox;
        private System.Windows.Forms.Label checkoutQuantityLabel;
    }
}