﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE2
{
    public class Kit
    {
        public string name { get; set; } //name of the kit
        public string description { get; set; } //description of the kit

        public string printOut //display member for a kit
        {
            get
            {
                return $"{ name }, { description }";
            }
        }
    }
}
