﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ECE2
{
    public partial class Update : Form
    {
        User activeUser = new User();
        List<Item> items = new List<Item>();
        List<string> errorList = new List<string>();
        Item currentItem;
        private static string DB_LOG = "DB_LOG.txt";

        public Update(User ActiveUser)
        {
            activeUser = ActiveUser;
            InitializeComponent();
            UpdateBinding();
        }

        private void ItemAddBack_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(activeUser);
            this.Hide();
            form.ShowDialog();
        }

        private void UpdateBinding()
        {
            DataAccess db = new DataAccess();
            items = db.PrintAllItems(); //update the list on this page
            ItemBox.DataSource = items;
            ItemBox.DisplayMember = "BasicInfo";
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            DataAccess db = new DataAccess();
            List<Item> items = new List<Item>();
            items = db.GetItem(IdSearchBox.Text);
            Item item = items.FirstOrDefault();
            if (item == null) 
            {
                errorList.Clear();
                errorList.Add("Item not found");
                ItemBox.DataSource = errorList;
            } else
            {
                //change the current text boxes to reflect the selected item
                ItemAddName.Text = item.Name;
                ItemAddDescription.Text = item.Description;
                ItemAddQuantity.Text = item.Quantity.ToString();
                ItemAddInstock.Text = item.InStock.ToString();
                currentItem = item;
            }
        }

        private void ClearError_Click(object sender, EventArgs e)
        {
            UpdateBinding();
        }

        private void UpdateItemButton_Click(object sender, EventArgs e) //this works very similarly to the add button under AddItem.cs, can check there for more documentation
        {
            errorList.Clear();

            string itemName = ItemAddName.Text;
            string itemDescription = ItemAddDescription.Text;
            string itemQuantity = ItemAddQuantity.Text;
            string itemInStock = ItemAddInstock.Text;

            bool noErrors = true;

            ///////////////////////////////////////errors///////////////////////////////////////


            //name errors
            if (itemName == null || itemName.Length == 0)
            {
                errorList.Add("Item name cannot be null");
                noErrors = false;
            }

            if (itemName.Length > 255)
            {
                errorList.Add("Item name must be less than 255 characters");
                noErrors = false;
            }

            //description errors
            if (itemDescription.Length > 255)
            {
                errorList.Add("Item description must be less than 255 characters");
                noErrors = false;
            }

            //quantity errors
            if (itemQuantity == null || itemQuantity.Length == 0)
            {
                errorList.Add("Item quantity cannot be null");
                noErrors = false;
            }

            if (int.TryParse(itemQuantity, out int quantityInt))
            {

                if (quantityInt < 0)
                {
                    errorList.Add("Item quantity must be greater than 0");
                }

            }
            else
            {
                errorList.Add("Quantity must be an integer");
                noErrors = false;
            }

            //instock errors
            if (int.TryParse(itemInStock, out int inStockInt))
            {

                if (inStockInt < 0)
                {
                    errorList.Add("Items in stock must be greater than 0");
                }

            }
            else
            {
                errorList.Add("In-stock must be an integer");
                noErrors = false;
            }

            if (itemInStock == null || itemInStock.Length == 0)
            {
                errorList.Add("In-stock cannot be null");
                noErrors = false;
            }

            ///////////////////////////////////////end of errors///////////////////////////////////////

            if (noErrors)
            {
                // ID = GenerateID().ToString(), Name = itemName, Description = itemDescription, Quantity = int.Parse(itemQuantity), InStock = int.Parse(itemInStock)
                Item newItem = new Item();
                newItem.ID = currentItem.ID;
                newItem.Name = itemName;
                newItem.Description = itemDescription;
                newItem.Quantity = int.Parse(itemQuantity);
                newItem.InStock = int.Parse(itemInStock);

                DataAccess db = new DataAccess();

                db.DeleteItem(int.Parse(newItem.ID)); //delete the old item

                List<Item> listForSending = new List<Item>();
                listForSending.Add(newItem);
                db.AddItem(listForSending); //place the new item
                UpdateBinding();

                WriteToLogFile($"===Item ID {newItem.ID} was updated by {activeUser.UserName} on {DateTime.Now}");

            }
            else
            {
                ItemBox.DataSource = errorList;
            }

        }

        /// <summary>
        /// Writes the string sent to it into the log file
        /// </summary>
        /// <param name="message">The message sent to the log file</param>
        private void WriteToLogFile(string message)
        {
            List<string> logEntries = new List<string>(); //Every string in this list is a line on the log file

            //Add each line in the log file as a string into the logEntries list since they will be deleted when the file is written to
            foreach (string line in System.IO.File.ReadLines(DB_LOG))
            {
                logEntries.Add(line);
            }

            logEntries.Add(message); //Add the user's message to the end of the list


            if (logEntries.Count > 300) //Remove the oldest message if the log goes over 300 items
            {
                logEntries.RemoveAt(0); //oldest message 
            }

            StreamWriter outFile = new StreamWriter(DB_LOG);

            //rewrite each string into the log file from order of oldest to newest
            foreach (string line in logEntries)
            {
                outFile.WriteLine(line);
            }

            outFile.Close();
        }
    }
}
