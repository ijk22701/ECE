﻿namespace ECE2
{
    partial class CreateKit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClearError = new System.Windows.Forms.Button();
            this.ItemAddBack = new System.Windows.Forms.Button();
            this.CreateKitButton = new System.Windows.Forms.Button();
            this.ItemBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.KitDescriptionBox = new System.Windows.Forms.TextBox();
            this.KitNameBox = new System.Windows.Forms.TextBox();
            this.KitBox = new System.Windows.Forms.ListBox();
            this.SelectKit = new System.Windows.Forms.Button();
            this.ItemIdBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AddItem = new System.Windows.Forms.Button();
            this.RemoveItem = new System.Windows.Forms.Button();
            this.UpdateQuantity = new System.Windows.Forms.Button();
            this.ItemQuantityBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.DeleteKit = new System.Windows.Forms.Button();
            this.ItemsInKit = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ClearError
            // 
            this.ClearError.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearError.Location = new System.Drawing.Point(1037, 915);
            this.ClearError.Name = "ClearError";
            this.ClearError.Size = new System.Drawing.Size(152, 87);
            this.ClearError.TabIndex = 35;
            this.ClearError.Text = "Clear Error";
            this.ClearError.UseVisualStyleBackColor = true;
            this.ClearError.Click += new System.EventHandler(this.ClearError_Click);
            // 
            // ItemAddBack
            // 
            this.ItemAddBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemAddBack.Location = new System.Drawing.Point(19, 915);
            this.ItemAddBack.Name = "ItemAddBack";
            this.ItemAddBack.Size = new System.Drawing.Size(206, 87);
            this.ItemAddBack.TabIndex = 30;
            this.ItemAddBack.Text = "Home";
            this.ItemAddBack.UseVisualStyleBackColor = true;
            this.ItemAddBack.Click += new System.EventHandler(this.ItemAddBack_Click);
            // 
            // CreateKitButton
            // 
            this.CreateKitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateKitButton.Location = new System.Drawing.Point(174, 99);
            this.CreateKitButton.Name = "CreateKitButton";
            this.CreateKitButton.Size = new System.Drawing.Size(136, 49);
            this.CreateKitButton.TabIndex = 29;
            this.CreateKitButton.Text = "Create Kit";
            this.CreateKitButton.UseVisualStyleBackColor = true;
            this.CreateKitButton.Click += new System.EventHandler(this.CreateKitButton_Click);
            // 
            // ItemBox
            // 
            this.ItemBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemBox.FormattingEnabled = true;
            this.ItemBox.HorizontalScrollbar = true;
            this.ItemBox.ItemHeight = 25;
            this.ItemBox.Location = new System.Drawing.Point(417, 284);
            this.ItemBox.Name = "ItemBox";
            this.ItemBox.Size = new System.Drawing.Size(772, 279);
            this.ItemBox.TabIndex = 28;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(151, 25);
            this.label2.TabIndex = 25;
            this.label2.Text = "Kit Description";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 25);
            this.label1.TabIndex = 24;
            this.label1.Text = "Kit Name";
            // 
            // KitDescriptionBox
            // 
            this.KitDescriptionBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitDescriptionBox.Location = new System.Drawing.Point(174, 62);
            this.KitDescriptionBox.Name = "KitDescriptionBox";
            this.KitDescriptionBox.Size = new System.Drawing.Size(1015, 31);
            this.KitDescriptionBox.TabIndex = 22;
            // 
            // KitNameBox
            // 
            this.KitNameBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitNameBox.Location = new System.Drawing.Point(174, 22);
            this.KitNameBox.Name = "KitNameBox";
            this.KitNameBox.Size = new System.Drawing.Size(1015, 31);
            this.KitNameBox.TabIndex = 20;
            // 
            // KitBox
            // 
            this.KitBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KitBox.FormattingEnabled = true;
            this.KitBox.HorizontalScrollbar = true;
            this.KitBox.ItemHeight = 25;
            this.KitBox.Location = new System.Drawing.Point(22, 284);
            this.KitBox.Name = "KitBox";
            this.KitBox.Size = new System.Drawing.Size(380, 604);
            this.KitBox.TabIndex = 36;
            // 
            // SelectKit
            // 
            this.SelectKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectKit.Location = new System.Drawing.Point(330, 99);
            this.SelectKit.Name = "SelectKit";
            this.SelectKit.Size = new System.Drawing.Size(136, 49);
            this.SelectKit.TabIndex = 37;
            this.SelectKit.Text = "Select Kit";
            this.SelectKit.UseVisualStyleBackColor = true;
            this.SelectKit.Click += new System.EventHandler(this.SelectKit_Click);
            // 
            // ItemIdBox
            // 
            this.ItemIdBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemIdBox.Location = new System.Drawing.Point(174, 182);
            this.ItemIdBox.Name = "ItemIdBox";
            this.ItemIdBox.Size = new System.Drawing.Size(136, 31);
            this.ItemIdBox.TabIndex = 38;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 185);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 25);
            this.label3.TabIndex = 39;
            this.label3.Text = "Item ID";
            // 
            // AddItem
            // 
            this.AddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddItem.Location = new System.Drawing.Point(330, 182);
            this.AddItem.Name = "AddItem";
            this.AddItem.Size = new System.Drawing.Size(136, 68);
            this.AddItem.TabIndex = 40;
            this.AddItem.Text = "Add Item";
            this.AddItem.UseVisualStyleBackColor = true;
            this.AddItem.Click += new System.EventHandler(this.AddItem_Click);
            // 
            // RemoveItem
            // 
            this.RemoveItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemoveItem.Location = new System.Drawing.Point(1037, 182);
            this.RemoveItem.Name = "RemoveItem";
            this.RemoveItem.Size = new System.Drawing.Size(152, 68);
            this.RemoveItem.TabIndex = 41;
            this.RemoveItem.Text = "Remove Item";
            this.RemoveItem.UseVisualStyleBackColor = true;
            this.RemoveItem.Click += new System.EventHandler(this.RemoveItem_Click);
            // 
            // UpdateQuantity
            // 
            this.UpdateQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateQuantity.Location = new System.Drawing.Point(472, 182);
            this.UpdateQuantity.Name = "UpdateQuantity";
            this.UpdateQuantity.Size = new System.Drawing.Size(158, 68);
            this.UpdateQuantity.TabIndex = 42;
            this.UpdateQuantity.Text = "Update Quantity In Kit";
            this.UpdateQuantity.UseVisualStyleBackColor = true;
            this.UpdateQuantity.Click += new System.EventHandler(this.UpdateQuantity_Click);
            // 
            // ItemQuantityBox
            // 
            this.ItemQuantityBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemQuantityBox.Location = new System.Drawing.Point(174, 219);
            this.ItemQuantityBox.Name = "ItemQuantityBox";
            this.ItemQuantityBox.Size = new System.Drawing.Size(136, 31);
            this.ItemQuantityBox.TabIndex = 43;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 25);
            this.label4.TabIndex = 44;
            this.label4.Text = "Quantity";
            // 
            // DeleteKit
            // 
            this.DeleteKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteKit.Location = new System.Drawing.Point(1037, 99);
            this.DeleteKit.Name = "DeleteKit";
            this.DeleteKit.Size = new System.Drawing.Size(152, 58);
            this.DeleteKit.TabIndex = 45;
            this.DeleteKit.Text = "Delete Kit";
            this.DeleteKit.UseVisualStyleBackColor = true;
            this.DeleteKit.Click += new System.EventHandler(this.DeleteKit_Click);
            // 
            // ItemsInKit
            // 
            this.ItemsInKit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ItemsInKit.FormattingEnabled = true;
            this.ItemsInKit.HorizontalScrollbar = true;
            this.ItemsInKit.ItemHeight = 25;
            this.ItemsInKit.Location = new System.Drawing.Point(417, 584);
            this.ItemsInKit.Name = "ItemsInKit";
            this.ItemsInKit.Size = new System.Drawing.Size(772, 304);
            this.ItemsInKit.TabIndex = 46;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(414, 568);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 47;
            this.label5.Text = "Items in selected kit";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(414, 268);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 13);
            this.label6.TabIndex = 48;
            this.label6.Text = "Items in allparts table";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 49;
            this.label7.Text = "All kits";
            // 
            // CreateKit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1207, 1025);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ItemsInKit);
            this.Controls.Add(this.DeleteKit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ItemQuantityBox);
            this.Controls.Add(this.UpdateQuantity);
            this.Controls.Add(this.RemoveItem);
            this.Controls.Add(this.AddItem);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ItemIdBox);
            this.Controls.Add(this.SelectKit);
            this.Controls.Add(this.KitBox);
            this.Controls.Add(this.ClearError);
            this.Controls.Add(this.ItemAddBack);
            this.Controls.Add(this.CreateKitButton);
            this.Controls.Add(this.ItemBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.KitDescriptionBox);
            this.Controls.Add(this.KitNameBox);
            this.Name = "CreateKit";
            this.Text = "CreateKit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ClearError;
        private System.Windows.Forms.Button ItemAddBack;
        private System.Windows.Forms.Button CreateKitButton;
        private System.Windows.Forms.ListBox ItemBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox KitDescriptionBox;
        private System.Windows.Forms.TextBox KitNameBox;
        private System.Windows.Forms.ListBox KitBox;
        private System.Windows.Forms.Button SelectKit;
        private System.Windows.Forms.TextBox ItemIdBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button AddItem;
        private System.Windows.Forms.Button RemoveItem;
        private System.Windows.Forms.Button UpdateQuantity;
        private System.Windows.Forms.TextBox ItemQuantityBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button DeleteKit;
        private System.Windows.Forms.ListBox ItemsInKit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}