﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ECE2
{
    public partial class User_config : Form
    {
        private List<User> userList = new List<User>();
        private List<string> errorList = new List<string>();
        private User currentUser = new User(); //used for selection purposes despite same name as other forms
        private User activeUser = new User(); //the current user actually logged into the database, only used for admin purposes
        private static string DB_LOG = "DB_LOG.txt";

        /// <summary>
        /// A constructor for the user_config form
        /// </summary>
        /// <param name="ActiveUser">the user signed in to the program</param>
        public User_config(User ActiveUser)
        {
            activeUser = ActiveUser;
            InitializeComponent();
            UpdateBinding();
        }

        public void UpdateBinding()
        {
            DataAccess db = new DataAccess();
            userList = db.GetUserList();
            userBox.DataSource = userList;
            userBox.DisplayMember = "printOut";
            UpdateUser.Hide();
            DeleteUser.Hide();
        }

        private void ItemAddBack_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1(activeUser);
            this.Hide();
            form.ShowDialog();
        }

        private void AddUser_Click(object sender, EventArgs e)
        {
            errorList.Clear();
            bool validEntry = true; //whether or not the user input was valid
            foreach (User user in userList) //checks through user list to make sure the username (primary key) is unique
            {
                if (UsernameEntry.Text.ToLower() == user.UserName.ToLower())
                {
                    errorList.Add("Username must be unique");
                    validEntry = false;
                    break;
                }
            }
            if (UsernameEntry.Text == "") //check for username entry
            {
                errorList.Add("Username cannot be empty");
                validEntry = false;
            }
            if (PasswordEntryBox.Text == "") //check for password entry
            {
                errorList.Add("Account must have a password");
                validEntry = false;
            }
            if (validEntry)
            {
                DataAccess db = new DataAccess();
                User newUser = new User();
                newUser.UserName = UsernameEntry.Text;
                newUser.Password = PasswordEntryBox.Text;
                if (adminBox.Checked) {
                    newUser.AdminRoll = "a"; //a = admin
                } else
                {
                    newUser.AdminRoll = "u"; //u = user, or normal user
                }
                db.AddUser(newUser);
                UpdateBinding();
                WriteToLogFile($"+++User {newUser.UserName} was created by {activeUser.UserName} at {DateTime.Now}");
            }
            else
            {
                userBox.DataSource = errorList;
            }
        }

        private void SelectUser_Click(object sender, EventArgs e)
        {
            if (UsernameEntry.Text.ToLower() == "root") //root user cannot be modified, this checks to make sure it is not attempted. 
            {
                errorList.Add("Cannot modify root user");
                userBox.DataSource = errorList;
            }
            else
            {

                DataAccess db = new DataAccess();
                errorList.Clear();
                bool match = false;
                foreach (User user in userList) //check if the username exists on the list of users
                {
                    if (UsernameEntry.Text.ToLower() == user.UserName.ToLower()) //if the username exists
                    {
                        match = true;
                        currentUser = db.GetUserByName(UsernameEntry.Text)[0]; //Gets the user from the database to fill their data in later
                        PasswordEntryBox.Text = currentUser.Password; //set user password to the selected user's password
                        List<User> currentUserOnly = new List<User>(); //for display purposes since listbox must display a list
                        currentUserOnly.Add(currentUser);  //add user to the display list
                        userBox.DataSource = currentUserOnly;
                        userBox.DisplayMember = "printOut";
                        UpdateUser.Show(); //show the buttons for update and delete since those are now available to the active user
                        DeleteUser.Show();
                        if (user.AdminRoll == "a") //set admin roll for the selected user
                        {
                            adminBox.Checked = true;
                        }
                        else
                        {
                            adminBox.Checked = false;
                        }

                        break;
                    }
                }
                if (!match)
                {
                    errorList.Add("Entry did not match a user on the list");
                    userBox.DataSource = errorList;
                }
            }
        }

        private void UpdateUser_Click(object sender, EventArgs e)
        {

            if (currentUser.UserName != "" && currentUser.UserName != null) //if currentUser is not empty and is not null
            {
                DataAccess db = new DataAccess();
                currentUser.Password = PasswordEntryBox.Text; //set password to whatever is currently in the password box
                if (adminBox.Checked) //determine if user is checked admin and set roll based on that
                {
                    currentUser.AdminRoll = "a";
                }
                else
                {
                    currentUser.AdminRoll = "u";
                }
                User updatedUser = currentUser;  //create the new user based on the modified current user

                db.DeleteUser(currentUser.UserName); //delete current user
                db.AddUser(updatedUser); //add new user

                UsernameEntry.Text = "";
                PasswordEntryBox.Text = "";
                UpdateBinding();
                WriteToLogFile($"===User {currentUser.UserName} was updated by {activeUser.UserName} at {DateTime.Now}");
                currentUser = new User(); //resets current user

            }
            else
            {
                errorList.Add("User not selected");
                userBox.DataSource = errorList;
            }
        }

        private void DeleteUser_Click(object sender, EventArgs e)
        {
            errorList.Clear();
            if (currentUser.UserName != "" && currentUser.UserName != null) //make sure user exists
            {
                DialogResult dialogResult = MessageBox.Show($"Are you sure you want to delete user \"{currentUser.UserName}\"?", "Delete User", MessageBoxButtons.YesNo); //dialog box prompting yes/no message
                if (dialogResult == DialogResult.Yes)
                {
                    DataAccess db = new DataAccess();
                    db.DeleteUser(currentUser.UserName); //deletes user
                    UpdateBinding();
                    UsernameEntry.Text = "";
                    PasswordEntryBox.Text = "";
                    WriteToLogFile($"---User {currentUser.UserName} was deleted by {activeUser.UserName} at {DateTime.Now}");
                    currentUser = new User(); //resets current user
                }

            } else
            {
                errorList.Add("User not selected");
                userBox.DataSource = errorList;
            }
        }

        private void ClearError_Click(object sender, EventArgs e)
        {
            UpdateBinding();
            currentUser = new User();
        }

        /// <summary>
        /// Writes the string sent to it into the log file
        /// </summary>
        /// <param name="message">The message sent to the log file</param>
        private void WriteToLogFile(string message)
        {
            List<string> logEntries = new List<string>(); //Every string in this list is a line on the log file

            //Add each line in the log file as a string into the logEntries list since they will be deleted when the file is written to
            foreach (string line in System.IO.File.ReadLines(DB_LOG))
            {
                logEntries.Add(line);
            }

            logEntries.Add(message); //Add the user's message to the end of the list


            if (logEntries.Count > 300) //Remove the oldest message if the log goes over 300 items
            {
                logEntries.RemoveAt(0); //oldest message 
            }

            StreamWriter outFile = new StreamWriter(DB_LOG);

            //rewrite each string into the log file from order of oldest to newest
            foreach (string line in logEntries)
            {
                outFile.WriteLine(line);
            }

            outFile.Close();
        }
    }
}
