﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE2
{
     public static class Helper
    {
        public static string CnnVal(string ID)
        {
            return ConfigurationManager.ConnectionStrings[ID].ConnectionString;
        }
    }
}
