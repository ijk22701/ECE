﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE2
{
    public class Item
    {
        public string ID { get; set; } //The ID of the item
        public string Name { get; set; } //The name of the item
        public string Description { get; set; } //The description of the item
        public int Quantity { get; set; } //The quantity of the item
        public int InStock { get; set; } //The amount of the item you have in stock

        
        public string BasicInfo //A string representing an item
        {
            get
            {
                return $"ID: {ID}, Name: {Name}, Description: {Description}, Quantity: {Quantity}, InStock: {InStock}, \n ";
            }

        }
    }
}
