﻿//////////////////////////////////////////////////////////////////////////
///Isaac Keith, Alec Vo
///Team HUSCII 03/14/2022
///
///Followed this tutorial for the basic structure of the database: https://www.youtube.com/watch?v=Et2khGnrIqc&t=38s "How to connect C# to SQL (the easy way)" by Tim Corey
///Made with Visual Studio 2022 using the Dapper extension
///For support in the future, email ijk22701@gmail.com

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECE2
{
    public class User
    {
        public string UserName { get; set; } //the username of the user
        public string Password { get; set; } //the password of the user
        public string AdminRoll { get; set; } //the admin roll of the user (MUST BE "a" OR "u"

        public string printOut //A string representing a user
        {
            get
            {
                return $"{UserName}, {Password}, {AdminRoll} ";
            }
        }

        /*
        public string[] getUserArray()
        {
            string[] userArray = {UserName, Password, AdminLevel };
            return userArray;
        }
        */

    }
}
